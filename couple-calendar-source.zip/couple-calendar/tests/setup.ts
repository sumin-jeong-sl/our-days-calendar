import 'fake-indexeddb/auto';
import { vi } from 'vitest';
// Dexie close() dispatches CustomEvent, which is not provided in all Node releases.
if (typeof CustomEvent === 'undefined') {
  vi.stubGlobal('CustomEvent', class<T = unknown> extends Event { detail: T; constructor(name: string, options?: CustomEventInit<T>) { super(name); this.detail = options?.detail as T; } });
}
