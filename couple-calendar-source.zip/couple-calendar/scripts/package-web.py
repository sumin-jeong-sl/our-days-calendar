from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[1]
dist = root / 'dist'
assert (dist / 'index.html').is_file() and (dist / 'sw.js').is_file(), 'Build the app first'
target = root.parent / 'couple-calendar-web.zip'
files = sorted(p for p in dist.rglob('*') if p.is_file())
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for file in files:
        archive.write(file, file.relative_to(dist).as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert 'index.html' in archive.namelist()
target.with_suffix('.sha256').write_text(hashlib.sha256(target.read_bytes()).hexdigest() + '  ' + target.name + '\n', encoding='utf-8')
print(json.dumps({'archive':str(target),'files':len(files),'bytes':target.stat().st_size},ensure_ascii=True))
