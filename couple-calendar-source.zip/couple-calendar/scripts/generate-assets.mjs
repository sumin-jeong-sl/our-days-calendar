// Development helper. Committed PNG files are ready to use; running this is optional.
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const sharp = (await import('sharp').catch(async () => {
  if (!process.env.OUR_DAYS_SHARP_PATH) throw new Error('Run npm install first.');
  return import(pathToFileURL(process.env.OUR_DAYS_SHARP_PATH).href);
})).default;
const iconDir = resolve('public/icons'), splashDir = resolve('public/splash');
await mkdir(iconDir, { recursive: true }); await mkdir(splashDir, { recursive: true });
const heart = `<path d="M256 329C224 302 153 260 153 206C153 170 195 157 220 181L256 215L292 181C317 157 359 170 359 206C359 260 288 302 256 329Z" fill="#c88c99" stroke="#a86778" stroke-width="6" stroke-linejoin="round"/>`;
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><rect width="512" height="512" rx="112" fill="#f6efea"/><ellipse cx="256" cy="256" rx="174" ry="134" transform="rotate(-24 256 256)" fill="#edf0e3" stroke="#ced7bf" stroke-width="5"/>${heart}<path d="m359 315 10 19 21 3-15 15 3 21-19-10-19 10 3-21-15-15 21-3Z" fill="#96a882"/></svg>`;
await writeFile(resolve(iconDir, 'icon.svg'), svg);
for (const [name, size] of [['icon-192.png',192],['icon-512.png',512],['maskable-512.png',512],['apple-touch-icon.png',180]]) {
  await sharp(Buffer.from(svg)).resize(size,size).png().toFile(resolve(iconDir,name));
}
const sizes = [[750,1334],[1125,2436],[1170,2532],[1179,2556],[1206,2622],[1242,2688],[1284,2778],[1290,2796],[1320,2868]];
for (const [width,height] of sizes) {
  const size = Math.round(width * .24);
  const image = await sharp(Buffer.from(svg)).resize(size,size).png().toBuffer();
  await sharp({ create: { width,height,channels:4,background:'#f9f6f2' } }).composite([{ input:image, left:Math.round((width-size)/2),top:Math.round((height-size)/2) }]).png().toFile(resolve(splashDir,`${width}x${height}.png`));
}
console.log('Created icons and 9 portrait iPhone launch images.');
