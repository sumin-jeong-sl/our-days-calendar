import { useCallback, useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { liveQuery } from 'dexie';
import { useRegisterSW } from 'virtual:pwa-register/react';
import { ArrowRight, CalendarDays, ChevronRight, Heart, House, Plus, Settings2, Sparkles, WifiOff } from 'lucide-react';
import { addDays, dateTime, daysBetween, daysTogether, formatDate, milestones, occurrences, onDate, today } from './domain/dates';
import type { Anniversary, CalendarEvent, Conflict, Payload, RecordValue, Snapshot } from './domain/model';
import { repository } from './storage/repository';
import { Calendar } from './ui/Calendar';
import { EventEditor } from './ui/EventEditor';
import { Settings } from './ui/Settings';
import { Onboarding } from './ui/Onboarding';
import { Empty, EventList, Modal, SectionTitle } from './ui/shared';
import { cloudStatus, startCloudSync, stopCloudSync, storedConnection } from './sync/cloud';

type Page = 'home' | 'calendar' | 'anniversaries' | 'settings';
type Dialog = { type: 'event'; event?: CalendarEvent; date: string } | { type: 'anniversary'; item?: Anniversary } | { type: 'import'; payload: Payload; hash: string | null } | { type: 'conflicts' };

export default function App() {
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null), [loaded, setLoaded] = useState(false), [fatal, setFatal] = useState('');
  const [page, setPage] = useState<Page>('home'), [dialog, setDialog] = useState<Dialog | null>(null), [toast, setToast] = useState('');
  const [online, setOnline] = useState(navigator.onLine), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const autoStatus = useSyncExternalStore(cloudStatus.subscribe, cloudStatus.get);
  useEffect(() => { void startCloudSync(); return stopCloudSync; }, []);
  const { needRefresh: [needRefresh], offlineReady: [offlineReady], updateServiceWorker } = useRegisterSW();
  useEffect(() => {
    const sub = liveQuery(() => repository.snapshot()).subscribe({ next: value => { setSnapshot(value); setLoaded(true); }, error: err => { setFatal(`기기 저장소를 읽지 못했습니다. ${String(err)}`); } });
    return () => sub.unsubscribe();
  }, []);
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener('online', update); window.addEventListener('offline', update);
    return () => { window.removeEventListener('online', update); window.removeEventListener('offline', update); };
  }, []);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(''), 6000); return () => clearTimeout(timer); }, [toast]);
  const closeDialog = useCallback(() => { setDialog(null); setError(''); }, []);
  const notify = useCallback((message: string) => setToast(message), []);
  const importPreview = useCallback((payload: Payload, hash: string | null) => { setError(''); setDialog({ type: 'import', payload, hash }); }, []);
  const navigate = (next: Page) => { setPage(next); window.scrollTo({ top: 0, behavior: 'auto' }); };
  const now = today();
  const visibleEvents = useMemo(() => snapshot?.events.filter(e => e.visibility === 'shared' || e.ownerId === snapshot.config.currentUserId) ?? [], [snapshot]);
  const upcoming = useMemo(() => occurrences(visibleEvents, now, addDays(now, 30)).filter(item => item.end.toMillis() > Date.now()), [visibleEvents, now]);
  const todayItems = useMemo(() => onDate(occurrences(visibleEvents, now, now), now), [visibleEvents, now]);
  const special = snapshot ? milestones(snapshot.config.couple, snapshot.anniversaries, now, addDays(now, 370)) : [];
  const addEvent = (date: string) => { setError(''); setDialog({ type: 'event', date }); };
  const edit = (event: CalendarEvent) => { setError(''); setDialog({ type: 'event', event, date: event.startAt.slice(0, 10) }); };
  const dday = snapshot ? daysTogether(snapshot.config.couple.anniversaryDate, now) : null;
  if (fatal) return <div className="fatal"><h1>저장 공간을 열 수 없습니다</h1><p>이 브라우저에서 IndexedDB가 차단되었거나 저장 공간이 부족합니다. Safari 일반 모드와 기기 용량을 확인해 주세요. 기존 데이터를 지우지 않았습니다.</p><pre>{fatal}</pre><button className="primary-button" onClick={() => location.reload()}>다시 열기</button></div>;
  if (!loaded) return <div className="loading"><Heart className="pulse" /><p>캘린더 불러오는 중…</p></div>;
  return <>
    {!snapshot ? <Onboarding onImport={importPreview} /> : <div className="app-shell">
      <header className="app-header"><button className="brand" onClick={() => navigate('home')}><span className="brand-mark"><Heart size={18} /></span><span>우리의 날들</span></button><button className="connection-badge" onClick={() => navigate('settings')}>{online ? <span className="status-dot" /> : <WifiOff size={12} />}{!online ? '오프라인' : autoStatus.mode === 'off' ? '기기 저장' : autoStatus.mode === 'synced' ? '자동 공유' : autoStatus.mode === 'error' ? '동기화 오류' : autoStatus.mode === 'conflict' ? '충돌 확인' : '동기화 대기'}</button></header>
      {needRefresh && <div className="update-banner"><span>새 버전이 있습니다. 백업 후 업데이트하세요.</span><button onClick={() => { if (!dialog) void updateServiceWorker(true); else notify('열린 편집 화면을 먼저 닫아 주세요.'); }}>업데이트</button></div>}
      {page === 'home' && <main className="page home-page"><div className="home-greeting"><p className="eyebrow">{formatDate(now, 'yyyy. MM. dd · cccc')}</p><h1>오늘의 일정</h1></div>
        <section className="relationship-card"><div className="relationship-top"><span>시작일 및 기념일</span><Heart size={18} strokeWidth={1.4} /></div><h2>{snapshot.config.couple.name}</h2><div className="dday">{dday === null ? <span className="dday-empty">시작일 미등록</span> : dday > 0 ? <><span>D+</span>{dday.toLocaleString()}<small>시작일부터</small></> : <><span>D−</span>{Math.abs(dday - 1)}<small>시작일까지</small></>}</div><div className="couple-tags">{snapshot.config.users.map((user, i) => <span key={user.id}>{i > 0 && <i>♥</i>}<b style={{ background: user.color + '25', color: user.color }}>{user.nickname.slice(0, 1)}</b>{user.nickname}</span>)}</div><div className="relationship-bottom">{snapshot.config.couple.anniversaryDate ? `${formatDate(snapshot.config.couple.anniversaryDate, 'yyyy. MM. dd')} 시작` : '설정에서 연애 시작일을 등록해 주세요'}<button aria-label="기념일 보기" onClick={() => navigate('anniversaries')}><ArrowRight size={16} /></button></div></section>
        <SectionTitle title="오늘 일정" action="일정 추가" onAction={() => addEvent(now)} />
        {todayItems.length ? <div className="card"><EventList items={todayItems} config={snapshot.config} onEdit={item => edit(item.event)} /></div> : <div className="card today-empty"><span><CalendarDays size={24} strokeWidth={1.4} /></span><div><strong>등록된 일정 없음</strong><p>일정을 추가할 수 있습니다.</p></div><button aria-label="오늘 일정 추가" onClick={() => addEvent(now)}><Plus size={18} /></button></div>}
        <SectionTitle title="다음 기념일" action="기념일 보기" onAction={() => navigate('anniversaries')} />
        {special[0] ? <button className="next-anniversary" onClick={() => navigate('anniversaries')}><span className="gift-icon"><Sparkles size={23} strokeWidth={1.5} /></span><div><span>{formatDate(special[0].date, 'M월 d일')}</span><strong>{special[0].title}</strong></div><b>{daysBetween(now, special[0].date) ? `D−${daysBetween(now, special[0].date)}` : '오늘'}</b></button> : <button className="next-anniversary" onClick={() => navigate('anniversaries')}><span className="gift-icon"><Heart size={23} /></span><div><span>기념일 미등록</span><strong>기념일 등록</strong></div><ChevronRight size={18} /></button>}
        <SectionTitle title="다가오는 일정" action="달력 열기" onAction={() => navigate('calendar')} />
        {upcoming.filter(item => item.date > now).slice(0, 3).length ? <div className="card upcoming-list">{upcoming.filter(item => item.date > now).slice(0, 3).map(item => <button key={item.key} className="upcoming-row" onClick={() => edit(item.event)}><span className="date-tile"><small>{formatDate(item.date, 'M월')}</small><b>{dateTime(item.date).day}</b></span><span><strong>{item.event.title}</strong><small>{item.event.allDay ? '종일' : item.start.toFormat('HH:mm')} · {item.event.category === 'together' ? '함께' : snapshot.config.users.find(u => u.id === item.event.ownerId)?.nickname}</small></span><ChevronRight size={17} /></button>)}</div> : <Empty title="예정된 일정 없음">캘린더에서 일정을 추가하세요.</Empty>}
        <button className="calendar-shortcut" onClick={() => navigate('calendar')}><CalendarDays size={18} /><span>월간 캘린더 보기</span><ArrowRight size={18} /></button>
        {!!snapshot.conflicts.length && <button className="conflict-callout" onClick={() => setDialog({ type: 'conflicts' })}>동시 수정 {snapshot.conflicts.length}건을 확인해 주세요 →</button>}
        <p className="local-footer">{offlineReady ? '오프라인 사용 준비 완료' : '일정은 이 기기에 저장됩니다'} · {storedConnection() ? autoStatus.message : '파일 공유 사용'}</p>
      </main>}
      {page === 'calendar' && <main><Calendar snapshot={snapshot} onAdd={addEvent} onEdit={item => edit(item.event)} /></main>}
      {page === 'anniversaries' && <main className="page"><div className="page-title"><div><p className="eyebrow">ANNIVERSARIES</p><h1>기념일</h1></div><button className="icon-button accent" aria-label="기념일 추가" onClick={() => setDialog({ type: 'anniversary' })}><Plus /></button></div><div className="anniversary-summary"><Heart size={23} /><p>{dday && dday > 0 ? `시작일부터 ${dday.toLocaleString()}일` : '시작일을 설정하면 기념일을 계산합니다.'}</p><small>100일은 시작일을 1일로 계산합니다.</small></div>
        <SectionTitle title="다가오는 기념일" />{special.length ? <div className="milestone-list">{special.map(item => <div className="milestone-card" key={item.id}><span className="milestone-symbol">{item.kind === 'relationship' ? <Heart size={18} /> : <CalendarDays size={18} />}</span><div><strong>{item.title}</strong><small>{formatDate(item.date)}</small></div><span className="dday-chip">{daysBetween(now, item.date) ? `D−${daysBetween(now, item.date)}` : '오늘'}</span></div>)}</div> : <Empty title="기념일 등록">설정에서 시작일을 등록하면 100일 단위와 주년을 계산합니다.</Empty>}
        <SectionTitle title="직접 등록한 기념일" action="추가하기" onAction={() => setDialog({ type: 'anniversary' })} />{snapshot.anniversaries.filter(a => !a.deletedAt).map(item => <button className="custom-anniversary card" key={item.id} onClick={() => setDialog({ type: 'anniversary', item })}><span><strong>{item.title}</strong><small>{formatDate(item.date, 'yyyy. MM. dd')} · {item.repeatType === 'yearly' ? '매년' : '한 번'}</small></span><ChevronRight size={17} /></button>)}<p className="hint">매년 기념일의 2월 29일은 평년에 2월 28일로 표시합니다.</p></main>}
      {page === 'settings' && <main><Settings snapshot={snapshot} onImport={importPreview} notify={notify} onConflicts={() => setDialog({ type: 'conflicts' })} /></main>}
      <nav className="bottom-nav" aria-label="주요 화면">{([{ page: 'home', label: '홈', icon: House }, { page: 'calendar', label: '캘린더', icon: CalendarDays }, { page: 'anniversaries', label: '기념일', icon: Heart }, { page: 'settings', label: '설정', icon: Settings2 }] as const).map(item => <button key={item.page} aria-current={page === item.page ? 'page' : undefined} className={page === item.page ? 'active' : ''} onClick={() => navigate(item.page)}><item.icon size={22} strokeWidth={page === item.page ? 2 : 1.6} /><span>{item.label}</span></button>)}</nav>
    </div>}
    {dialog?.type === 'event' && snapshot && <Modal title={dialog.event ? '일정 편집' : '일정 추가'} onClose={closeDialog}><EventEditor config={snapshot.config} event={dialog.event} date={dialog.date} onSaved={() => { closeDialog(); notify('일정을 저장했습니다.'); }} /></Modal>}
    {dialog?.type === 'anniversary' && snapshot && <Modal title={dialog.item ? '기념일 편집' : '기념일 추가'} onClose={closeDialog}><AnniversaryEditor item={dialog.item} onSaved={() => { closeDialog(); notify('기념일을 저장했습니다.'); }} /></Modal>}
    {dialog?.type === 'import' && <Modal title={dialog.payload.kind === 'share' ? '공유 파일 확인' : '백업 복원 확인'} onClose={closeDialog}><div className="import-review"><span className="review-heart"><Heart size={28} /></span><h3>{dialog.payload.couple.name}</h3><p>{dialog.payload.events.filter(e => !e.deletedAt).length}개 일정 · {dialog.payload.anniversaries.filter(a => !a.deletedAt).length}개 기념일</p><p>{dialog.payload.kind === 'share' ? `보낸 사람: ${senderName(dialog.payload)}. 처음 연결하면 다른 사용자의 공간으로 열립니다.` : '전체 백업입니다. 비공개 내용을 포함할 수 있으므로 본인의 백업인지 확인하세요.'}</p><p className="hint">기존 데이터와 버전을 비교하여 병합합니다. 동시 수정은 사본을 보존합니다. 다른 커플의 파일은 기존 기록이 있을 때 가져올 수 없습니다.</p>{error && <p className="error" role="alert">{error}</p>}<button className="primary-button full" disabled={busy} onClick={async () => { setBusy(true); setError(''); try { const result = await repository.importPayload(dialog.payload, dialog.hash); closeDialog(); notify(`${result.paired ? '캘린더를 연결했습니다. ' : ''}${result.added}건 반영${result.conflicts ? ` · 충돌 ${result.conflicts}건 확인 필요` : ''}`); } catch (err) { setError((err as Error).message); } finally { setBusy(false); } }}>{busy ? '반영 중…' : '확인하고 가져오기'}</button></div></Modal>}
    {dialog?.type === 'conflicts' && snapshot && <Modal title="동시 수정 확인" onClose={closeDialog}><p className="hint">두 기기에서 같은 항목을 수정했습니다. 아래에서 유지할 버전을 선택하세요. 선택한 결과는 공유 설정에 따라 전달됩니다.</p>{snapshot.conflicts.length ? snapshot.conflicts.map(conflict => <ConflictCard key={conflict.id} conflict={conflict} notify={notify} />) : <Empty title="충돌 해결 완료" />}</Modal>}
    {toast && <div className="toast" role="status">{toast}</div>}
  </>;
}

function senderName(payload: Payload): string {
  if (payload.kind !== 'share') return '';
  const senderId = payload.senderId;
  return payload.users.find(u => u.id === senderId)?.nickname ?? '';
}
function AnniversaryEditor({ item, onSaved }: { item?: Anniversary; onSaved: () => void }) {
  const [title, setTitle] = useState(item?.title ?? ''), [date, setDate] = useState(item?.date ?? today()), [repeatType, setRepeatType] = useState<'once' | 'yearly'>(item?.repeatType ?? 'yearly');
  const [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const handle = async (action: () => Promise<void>) => { setBusy(true); setError(''); try { await action(); onSaved(); } catch (err) { setError((err as Error).message); } finally { setBusy(false); } };
  return <form className="form" onSubmit={e => { e.preventDefault(); void handle(() => repository.saveAnniversary({ title: title.trim(), date, repeatType }, item?.id)); }}><label>기념일 이름<input value={title} onChange={e => setTitle(e.target.value)} placeholder="예: 생일" required maxLength={120} /></label><label>날짜<input type="date" value={date} onChange={e => setDate(e.target.value)} required /></label><label>반복<select value={repeatType} onChange={e => setRepeatType(e.target.value as 'once' | 'yearly')}><option value="yearly">매년</option><option value="once">한 번</option></select></label><p className="hint">기념일은 두 사람에게 공유됩니다.</p>{error && <p className="error" role="alert">{error}</p>}<div className="form-actions">{item && <button type="button" className="danger-button" disabled={busy} onClick={() => { if (window.confirm('이 기념일을 삭제할까요?')) void handle(() => repository.deleteAnniversary(item.id)); }}>삭제</button>}<button className="primary-button" disabled={busy}>{busy ? '저장 중…' : '기념일 저장'}</button></div></form>;
}
function describe(record: RecordValue): string {
  if (record.deletedAt) return '삭제된 항목';
  if ('startAt' in record) return `${record.title}\n${record.startAt} → ${record.endAt}\n${record.description || '메모 없음'}`;
  if ('date' in record) return `${record.title}\n${record.date}`;
  if ('name' in record) return `${record.name}\n${record.anniversaryDate || '시작일 없음'}`;
  return record.nickname;
}
function ConflictCard({ conflict, notify }: { conflict: Conflict; notify: (message: string) => void }) {
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  return <div className="conflict-card"><h3>{({ event: '일정', anniversary: '기념일', couple: '공간 설정', user: '사용자' })[conflict.kind]} 버전 선택</h3><div className="conflict-options">{(['local', 'remote'] as const).map(choice => <div key={choice}><span>{choice === 'local' ? '이 기기의 사본' : '받은 파일의 사본'}</span><p>{describe(conflict[choice])}</p><small>{new Date(conflict[choice].updatedAt).toLocaleString('ko-KR')}</small><button className="outline-button full" disabled={busy} onClick={async () => { setBusy(true); setError(''); try { await repository.resolveConflict(conflict.id, choice); notify('선택한 버전을 저장했습니다.'); } catch (err) { setError((err as Error).message); } finally { setBusy(false); } }}>이 버전 유지</button></div>)}</div>{error && <p className="error" role="alert">{error}</p>}</div>;
}
