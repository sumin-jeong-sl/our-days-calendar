import type { Clock, Conflict, EntityKind, RecordValue, Versioned } from './model';

export function compareClocks(a: Clock, b: Clock): 'equal' | 'before' | 'after' | 'concurrent' {
  let less = false, more = false;
  for (const key of new Set([...Object.keys(a), ...Object.keys(b)])) {
    less ||= (a[key] ?? 0) < (b[key] ?? 0);
    more ||= (a[key] ?? 0) > (b[key] ?? 0);
  }
  return less && more ? 'concurrent' : less ? 'before' : more ? 'after' : 'equal';
}
export function joinClocks(...clocks: Clock[]): Clock {
  const result: Clock = {};
  for (const clock of clocks) for (const [key, value] of Object.entries(clock)) result[key] = Math.max(result[key] ?? 0, value);
  return result;
}
export function revise<T extends Versioned>(record: T, deviceId: string, otherClock: Clock = {}): T {
  const clock = joinClocks(record.clock, otherClock);
  clock[deviceId] = (clock[deviceId] ?? 0) + 1;
  return { ...record, clock, version: Math.max(record.version + 1, ...Object.values(clock)), updatedAt: new Date().toISOString(), updatedBy: deviceId };
}
const canonical = (value: unknown): string => {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, val]) => JSON.stringify(key) + ':' + canonical(val)).join(',') + '}';
  return JSON.stringify(value);
};
export function mergeRecord<T extends RecordValue>(local: T | undefined, remote: T, kind: EntityKind): { record: T; conflict?: Conflict; changed: boolean } {
  if (!local) return { record: remote, changed: true };
  const relation = compareClocks(local.clock, remote.clock);
  // Transport strips deleted content. Equal deletion clocks remain the same deletion.
  if (relation === 'equal' && local.deletedAt && remote.deletedAt) return { record: local, changed: false };
  if (relation === 'before') return { record: remote, changed: true };
  if (relation === 'after' || (relation === 'equal' && canonical(local) === canonical(remote))) return { record: local, changed: false };
  // Delete wins provisionally. Both candidates remain in the conflict inbox.
  const record = remote.deletedAt && !local.deletedAt ? remote : local;
  const conflict: Conflict = {
    id: `${kind}:${remote.id}:${canonical(remote.clock)}:${remote.updatedBy}:${remote.updatedAt}`,
    kind, entityId: remote.id, local, remote
  };
  return { record, conflict, changed: true };
}
