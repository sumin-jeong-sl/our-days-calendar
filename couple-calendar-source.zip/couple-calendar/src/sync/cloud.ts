import { liveQuery } from 'dexie';
import { repository } from '../storage/repository';
import { connectionSchema, randomSecret, sealCloud, openCloud, payloadFingerprint, type CloudConnection, type CloudFirebaseConfig } from './cloudCrypto';

const STORAGE = 'our-days-cloud-v1';
type CloudStatus = { mode: 'off' | 'connecting' | 'synced' | 'pending' | 'offline' | 'conflict' | 'error'; message: string; lastSentAt: string | null };
let status: CloudStatus = { mode: 'off', message: '자동 동기화 꺼짐', lastSentAt: null };
const watchers = new Set<() => void>();
function report(mode: CloudStatus['mode'], message: string, sent = false) { status = { mode, message, lastSentAt: sent ? new Date().toISOString() : status.lastSentAt }; watchers.forEach(fn => fn()); }
export const cloudStatus = { get: () => status, subscribe: (fn: () => void) => { watchers.add(fn); return () => { watchers.delete(fn); }; } };
export function storedConnection(): CloudConnection | null { try { const text = localStorage.getItem(STORAGE); return text ? connectionSchema.parse(JSON.parse(text)) : null; } catch { return null; } }
async function client(config: CloudFirebaseConfig) {
  const [appSDK, authSDK, sdk] = await Promise.all([import('firebase/app'), import('firebase/auth'), import('firebase/database')]);
  const appName = 'our-days-' + config.projectId;
  const app = appSDK.getApps().find(a => a.name === appName) ?? appSDK.initializeApp(config, appName);
  const auth = authSDK.getAuth(app); await auth.authStateReady();
  await authSDK.setPersistence(auth, authSDK.browserLocalPersistence);
  const user = auth.currentUser ?? (await authSDK.signInAnonymously(auth)).user;
  return { db: sdk.getDatabase(app), uid: user.uid, sdk };
}
export async function createCloudConnection(firebase: CloudFirebaseConfig) {
  const snap = await repository.snapshot(); if (!snap) throw new Error('캘린더를 먼저 만드세요.');
  if (storedConnection()) throw new Error('이미 자동 동기화에 연결되어 있습니다.');
  const c: CloudConnection = { firebase, room: randomSecret(), key: randomSecret(), coupleId: snap.config.couple.id };
  const payload = await repository.createPayload('share'); if (payload.kind !== 'share') throw new Error();
  const bootstrap = await sealCloud(payload, c.key);
  const { db, uid, sdk } = await client(firebase);
  const result = await sdk.runTransaction(sdk.ref(db, `rooms/${c.room}/meta`), old => old ? undefined : { slot0: uid, bootstrap }, { applyLocally: false });
  if (!result.committed) throw new Error('연결 생성에 실패했습니다.');
  localStorage.setItem(STORAGE, JSON.stringify(c)); await startCloudSync(); return c;
}
export async function joinCloudConnection(c: CloudConnection) {
  if (storedConnection()) throw new Error('이미 연결되어 있습니다. 먼저 자동 동기화를 해제하세요.');
  const { db, uid, sdk } = await client(c.firebase), metaRef = sdk.ref(db, `rooms/${c.room}/meta`);
  const meta = (await sdk.get(metaRef)).val(); if (!meta) throw new Error('연결 정보를 찾을 수 없습니다.');
  const payload = await openCloud(meta.bootstrap, c.key);
  if (payload.couple.id !== c.coupleId) throw new Error('연결된 캘린더 정보가 다릅니다.');
  const local = await repository.snapshot();
  if (local && local.config.couple.id !== c.coupleId && (local.events.length || local.anniversaries.length || local.withdrawals.length || local.conflicts.length)) throw new Error('기존 캘린더에 데이터가 있습니다. 먼저 백업하세요. 다른 캘린더로 자동 전환하지 않습니다.');
  if (local?.config.couple.id === c.coupleId && local.config.currentUserId === payload.senderId) throw new Error('본인이 만든 연결 링크입니다. 상대방 기기에서 연결하세요.');
  if (meta.slot1 && meta.slot1 !== uid) throw new Error('이미 두 기기가 연결되어 있습니다. 기기를 바꾼 경우 관리자가 연결 슬롯을 복구해야 합니다.');
  if (meta.slot0 === uid) throw new Error('연결을 만든 기기입니다. 상대방 기기에서 연결하세요.');
  if (meta.slot1 !== uid) {
    // RTDB initially invokes transactions with an empty local cache, even
    // after get(). Seed from the verified snapshot; the server still retries
    // and validates against its current value before committing.
    const result = await sdk.runTransaction(metaRef, old => {
      const current = old ?? meta;
      return !current.slot1 ? { ...current, slot1: uid } : undefined;
    }, { applyLocally: false });
    if (!result.committed) throw new Error('연결이 이미 사용되었습니다.');
  }
  await repository.importPayload(payload, null, 'automatic');
  localStorage.setItem(STORAGE, JSON.stringify(c)); await startCloudSync();
}
let stop: (() => void) | null = null, starting: Promise<void> | null = null, generation = 0;
export function startCloudSync(): Promise<void> {
  if (starting) return starting;
  starting = run().finally(() => { starting = null; }); return starting;
}
async function run() {
  const runGeneration = ++generation;
  stop?.(); stop = null;
  const c = storedConnection(); if (!c) { report('off', '자동 동기화 꺼짐'); return; }
  report('connecting', '동기화 연결 중');
  try {
    const { db, uid, sdk } = await client(c.firebase);
    if (runGeneration !== generation || storedConnection()?.room !== c.room) return;
    let disposed = false, ready = false, remoteQueue = Promise.resolve(), publishing = false, queued = false, fingerprint = '', timer: ReturnType<typeof setTimeout> | undefined;
    const seen = new Map<string, string>();
    const publish = async () => {
      if (disposed || !ready) return;
      if (publishing) { queued = true; return; }
      if (!navigator.onLine) { report('offline', '오프라인 · 기기 저장 유지'); return; }
      publishing = true;
      try {
        const snap = await repository.snapshot(); if (!snap || snap.config.couple.id !== c.coupleId) throw new Error('연결된 캘린더가 다릅니다.');
        if (snap.conflicts.length) { report('conflict', '동시 수정 · 버전 선택 필요'); return; }
        const payload = await repository.createPayload('share'); if (payload.kind !== 'share') throw new Error();
        const next = payloadFingerprint(payload); if (next === fingerprint) return;
        report('pending', '변경사항 업로드 중');
        const cipher = await sealCloud(payload, c.key);
        if (disposed) return;
        await sdk.set(sdk.ref(db, `rooms/${c.room}/packets/${uid}`), cipher);
        fingerprint = next; report('synced', '업로드 완료 · 상대 수신 대기', true);
      } catch (error) { report('error', `동기화 실패 · 기기 데이터 유지: ${(error as Error).message}`); }
      finally { publishing = false; if (queued) { queued = false; schedule(); } }
    };
    const schedule = () => { if (timer) clearTimeout(timer); timer = setTimeout(() => void publish(), 600); };
    const unsubscribePackets = sdk.onValue(sdk.ref(db, `rooms/${c.room}/packets`), value => {
      const packets = value.val() as Record<string, string> | null;
      remoteQueue = remoteQueue.then(async () => {
        for (const [sender, text] of Object.entries(packets ?? {})) {
          if (sender === uid || seen.get(sender) === text || disposed) continue;
          const payload = await openCloud(text, c.key);
          if (disposed) return;
          if (payload.couple.id !== c.coupleId) throw new Error('다른 캘린더의 동기화 데이터입니다.');
          await repository.importPayload(payload, null, 'automatic'); seen.set(sender, text);
          report('synced', '상대방 변경사항 반영 완료');
        }
        ready = true; schedule();
      }).catch(error => report('error', `동기화 수신 실패 · 기기 데이터 유지: ${(error as Error).message}`));
    }, error => report('error', '동기화 권한 또는 연결 오류: ' + error.message));
    const unsubscribeConnection = sdk.onValue(sdk.ref(db, '.info/connected'), value => { if (value.val()) schedule(); else report('offline', '연결 대기 · 기기 저장 유지'); });
    const localSub = liveQuery(() => repository.snapshot()).subscribe({ next: schedule, error: error => report('error', String(error)) });
    const focus = () => { if (document.visibilityState === 'visible') schedule(); };
    const retry = setInterval(schedule, 10000); window.addEventListener('online', schedule); document.addEventListener('visibilitychange', focus);
    stop = () => { disposed = true; if (timer) clearTimeout(timer); clearInterval(retry); unsubscribePackets(); unsubscribeConnection(); localSub.unsubscribe(); window.removeEventListener('online', schedule); document.removeEventListener('visibilitychange', focus); };
  } catch (error) { if (runGeneration === generation) report('error', '자동 동기화 설정 확인 필요: ' + (error as Error).message); }
}
export function disconnectCloud() { generation++; stop?.(); stop = null; localStorage.removeItem(STORAGE); report('off', '자동 동기화 꺼짐 · 기기 데이터 유지'); }
export function stopCloudSync() { generation++; stop?.(); stop = null; }
