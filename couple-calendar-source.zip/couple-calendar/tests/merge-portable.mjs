import { test } from 'node:test';
import assert from 'node:assert/strict';
import { compareClocks, joinClocks, mergeRecord, revise } from '../src/domain/merge.ts';
import { shareEvents, shareWithdrawals } from '../src/sync/projection.ts';

const base = { id:'event-1', title:'original', clock:{a:1}, version:1, updatedBy:'a', createdAt:'2026-10-01T00:00:00Z', updatedAt:'2026-10-01T00:00:00Z', deletedAt:null };
test('vector clocks detect sequential and simultaneous edits independent of timestamps', () => {
  assert.equal(compareClocks({a:1},{a:2}), 'before');
  assert.equal(compareClocks({a:2},{a:1}), 'after');
  assert.equal(compareClocks({a:2},{a:1,b:1}), 'concurrent');
  assert.equal(compareClocks({a:1},{a:1}), 'equal');
});
test('duplicate imported record is idempotent', () => {
  const result = mergeRecord(base, structuredClone(base), 'event');
  assert.equal(result.changed,false); assert.equal(result.conflict,undefined);
});
test('concurrent edits preserve both candidates', () => {
  const local = {...revise(base,'a'),title:'my edit'};
  const remote = {...revise(base,'b'),title:'partner edit'};
  const result = mergeRecord(local,remote,'event');
  assert.equal(result.conflict.local.title,'my edit');
  assert.equal(result.conflict.remote.title,'partner edit');
});
test('resolution is causally newer than both concurrent revisions', () => {
  const a = revise(base,'a'), b = revise(base,'b');
  const chosen = revise(a,'a',joinClocks(a.clock,b.clock));
  assert.equal(compareClocks(chosen.clock,a.clock),'after');
  assert.equal(compareClocks(chosen.clock,b.clock),'after');
});
test('older live record never resurrects a deletion', () => {
  const deleted = {...revise(base,'a'), deletedAt:'2026-10-02T00:00:00Z'};
  assert.equal(mergeRecord(deleted,base,'event').record.deletedAt,deleted.deletedAt);
});
test('sanitized deletion acknowledgement does not create a false conflict', () => {
  const deleted = {...revise(base,'a'),deletedAt:'2026-10-02T00:00:00Z'};
  const acknowledgement = {...deleted,title:'삭제된 일정',description:'',startAt:'2000-01-01',endAt:'2000-01-02'};
  const result = mergeRecord(deleted,acknowledgement,'event');
  assert.equal(result.changed,false); assert.equal(result.conflict,undefined);
});
test('concurrent delete/edit preserves a recoverable conflict', () => {
  const deleted = {...revise(base,'a'),deletedAt:'2026-10-02T00:00:00Z'};
  const edited = {...revise(base,'b'),title:'new title'};
  const result = mergeRecord(edited,deleted,'event');
  assert.ok(result.record.deletedAt); assert.equal(result.conflict.local.title,'new title');
});
test('shared export excludes all private records and erases deleted content', () => {
  const records = [{...base,visibility:'private',description:'SECRET'}, {...base,id:'public',visibility:'shared'}, {...base,id:'deleted',visibility:'shared',deletedAt:'2026-10-02T00:00:00Z',description:'DELETED SECRET',startAt:'2026-10-01',endAt:'2026-10-02'}];
  const text = JSON.stringify(shareEvents(records));
  assert.equal(shareEvents(records).length,2); assert.ok(!text.includes('SECRET')); assert.ok(!text.includes('private'));
});
test('privacy withdrawals whitelist only metadata', () => {
  const output = shareWithdrawals([{...base,ownerId:'user-1',deletedAt:'2026-10-02T00:00:00Z',description:'SECRET',startAt:'PRIVATE TIME'}]);
  assert.ok(!JSON.stringify(output).includes('SECRET')); assert.ok(!JSON.stringify(output).includes('PRIVATE TIME')); assert.ok(!('title' in output[0]));
});
