@echo off
setlocal
cd /d "%~dp0"
set "CALENDAR_NODE="
for /f "delims=" %%I in ('where node 2^>nul') do if not defined CALENDAR_NODE set "CALENDAR_NODE=%%I"
if not defined CALENDAR_NODE if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" set "CALENDAR_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if not defined CALENDAR_NODE (
  echo Node.js was not found. Install Node.js first.
  pause
  exit /b 1
)
if not exist "dist\index.html" (
  echo Build the calendar first. See README.md.
  pause
  exit /b 1
)
echo Open http://127.0.0.1:4173/ in your browser.
echo Stop the server with Ctrl+C.
"%CALENDAR_NODE%" "node_modules\vite\bin\vite.js" preview --host 127.0.0.1 --port 4173 --strictPort
