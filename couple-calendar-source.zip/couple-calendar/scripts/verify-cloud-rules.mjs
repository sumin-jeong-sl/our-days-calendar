// Explicit administrator validation using only synthetic test data.
import { readFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { initializeApp, deleteApp } from 'firebase/app';
import { getAuth, signInAnonymously } from 'firebase/auth';
import { randomBytes } from 'node:crypto';
const config = JSON.parse(await readFile(new URL('../public/sync-config.json', import.meta.url), 'utf8'));
const clients = [];
async function request(client, path, method = 'GET', value) {
  const url = new URL(`${config.databaseURL}/${path}.json`);
  if (client) url.searchParams.set('auth', client.token);
  return fetch(url, { method, body: value === undefined ? undefined : JSON.stringify(value), signal: AbortSignal.timeout(15000) });
}
try {
  for (let i = 0; i < 3; i++) {
    const app = initializeApp(config, 'rules-test-' + randomBytes(8).toString('hex'));
    const user = (await signInAnonymously(getAuth(app))).user;
    clients.push({ app, uid: user.uid, token: await user.getIdToken() });
  }
  const [a, b, outsider] = clients, room = randomBytes(32).toString('hex');
  assert.equal((await request(a, `rooms/${room}/meta`, 'PUT', { slot0: a.uid, bootstrap: 'synthetic encrypted bootstrap' })).status, 200);
  assert.equal((await request(b, `rooms/${room}/meta`, 'PUT', { slot0: a.uid, slot1: b.uid, bootstrap: 'synthetic encrypted bootstrap' })).status, 200);
  assert.equal((await request(a, `rooms/${room}/packets/${a.uid}`, 'PUT', 'synthetic encrypted packet')).status, 200);
  const packet = await request(b, `rooms/${room}/packets/${a.uid}`); assert.equal(packet.status, 200); assert.equal(await packet.json(), 'synthetic encrypted packet');
  assert.equal((await request(outsider, `rooms/${room}/packets`)).status, 401);
  assert.equal((await request(b, `rooms/${room}/packets/${a.uid}`, 'PUT', 'unauthorized overwrite')).status, 401);
  assert.equal((await request(outsider, `rooms/${room}/meta`, 'PUT', { slot0: a.uid, slot1: outsider.uid, bootstrap: 'synthetic encrypted bootstrap' })).status, 401);
  assert.equal((await request(a, 'rooms')).status, 401);
  assert.equal((await request(null, `rooms/${room}/packets`)).status, 401);
  console.log('PASS: two members read; outsider read, foreign write, third join, listing and unauthenticated read denied.');
} finally {
  await Promise.all(clients.map(c => deleteApp(c.app)));
}
