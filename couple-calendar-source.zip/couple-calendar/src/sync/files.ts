import { z } from 'zod';
import { payloadSchema, type Payload } from '../domain/model';

export const MAX_FILE_SIZE = 8 * 1024 * 1024;
const envelopeSchema = z.object({
  app: z.literal('our-days-encrypted'), schemaVersion: z.literal(1),
  algorithm: z.literal('AES-256-GCM/PBKDF2-SHA256'), iterations: z.literal(210000),
  salt: z.string().max(40), iv: z.string().max(30), ciphertext: z.string().max(12 * 1024 * 1024)
});
const bytesToBase64 = (buffer: Uint8Array) => {
  let str = '';
  for (let i = 0; i < buffer.length; i += 8192) str += String.fromCharCode(...buffer.slice(i, i + 8192));
  return btoa(str);
};
const fromBase64 = (str: string) => Uint8Array.from(atob(str), c => c.charCodeAt(0));
const buffer = (value: Uint8Array) => value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength) as ArrayBuffer;
export function validatePassword(password: string) {
  if (!/^[0-9]{4}$/.test(password)) throw new Error('공유 PIN은 숫자 4자리로 입력하세요.');
}
function validateImportPassword(password: string) {
  // Keep existing v1 files readable while new exports require a four-digit PIN.
  if (!/^[0-9]{4}$/.test(password) && (password.length < 12 || password.length > 200)) throw new Error('숫자 4자리 PIN 또는 이전 파일의 기존 암호를 입력하세요.');
}
async function derive(password: string, salt: Uint8Array, importing = false) {
  if (importing) validateImportPassword(password); else validatePassword(password);
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: buffer(salt), iterations: 210000, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
export async function secretHash(password: string, importing = false): Promise<string> {
  if (importing) validateImportPassword(password); else validatePassword(password);
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(password));
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, '0')).join('');
}
export async function encryptPayload(payload: Payload, password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await derive(password, salt);
  const text = JSON.stringify(payloadSchema.parse(payload));
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: buffer(iv) }, key, new TextEncoder().encode(text));
  return JSON.stringify({ app: 'our-days-encrypted', schemaVersion: 1, algorithm: 'AES-256-GCM/PBKDF2-SHA256', iterations: 210000, salt: bytesToBase64(salt), iv: bytesToBase64(iv), ciphertext: bytesToBase64(new Uint8Array(ciphertext)) });
}
export async function parseFile(file: Pick<File, 'size' | 'text'>, password?: string): Promise<{ payload: Payload; hash: string | null }> {
  if (file.size > MAX_FILE_SIZE) throw new Error('파일은 8MB 이하만 가져올 수 있습니다.');
  let value: unknown;
  try { value = JSON.parse(await file.text()); } catch { throw new Error('읽을 수 없는 JSON 파일입니다.'); }
  let hash: string | null = null;
  if (value && typeof value === 'object' && 'app' in value && value.app === 'our-days-encrypted') {
    const envelope = envelopeSchema.safeParse(value);
    if (!envelope.success) throw new Error('지원하지 않는 암호화 파일 형식입니다.');
    if (!password) throw new Error('공유 암호를 입력해 주세요.');
    hash = await secretHash(password, true);
    try {
      const salt = fromBase64(envelope.data.salt), iv = fromBase64(envelope.data.iv);
      if (salt.length !== 16 || iv.length !== 12) throw new Error();
      const key = await derive(password, salt, true);
      const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: buffer(iv) }, key, buffer(fromBase64(envelope.data.ciphertext)));
      value = JSON.parse(new TextDecoder().decode(plain));
    } catch { throw new Error('암호가 다르거나 파일이 손상되었습니다.'); }
  }
  const parsed = payloadSchema.safeParse(value);
  if (!parsed.success) throw new Error('백업 형식 또는 스키마 버전이 올바르지 않습니다. ' + parsed.error.issues[0]?.message);
  if (parsed.data.kind === 'share' && !hash) throw new Error('공유 파일은 반드시 암호화되어 있어야 합니다.');
  return { payload: parsed.data, hash };
}
export async function saveFile(text: string, filename: string): Promise<void> {
  const file = new File([text], filename, { type: 'application/json' });
  if (file.size > MAX_FILE_SIZE) throw new Error('파일이 8MB를 초과합니다. 이 버전의 복원 제한을 넘으므로 내보내기를 중단했습니다.');
  if (navigator.canShare?.({ files: [file] })) {
    try { await navigator.share({ files: [file], title: '우리의 날들' }); return; }
    catch (error) { if (error instanceof DOMException && error.name === 'AbortError') throw new Error('파일 저장을 취소했습니다.'); }
  }
  const url = URL.createObjectURL(file);
  const anchor = document.createElement('a');
  anchor.href = url; anchor.download = filename; document.body.appendChild(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

// Optional future transports implement delivery only; local merge/persistence stay independent.
export interface SyncTransport {
  mode: 'manual' | 'automatic';
  send(contents: string): Promise<void>;
  receive(): Promise<string[]>;
}
export const activeSyncMode = 'manual' as const;
