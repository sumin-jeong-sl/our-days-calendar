import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  base: './',
  plugins: [react(), VitePWA({
    registerType: 'prompt',
    includeAssets: ['icons/*.png', 'icons/icon.svg', 'splash/*.png'],
    manifest: {
      name: '우리의 날들 · 커플 캘린더', short_name: '우리의 날들', lang: 'ko',
      description: '두 사람의 일상을 담는 오프라인 커플 캘린더',
      start_url: './', scope: './', display: 'standalone',
      background_color: '#f9f6f2', theme_color: '#f9f6f2',
      icons: [
        { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
        { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
        { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
      ]
    },
    workbox: {
      globPatterns: ['**/*.{js,css,html,png,svg,webmanifest}'],
      navigateFallback: 'index.html', cleanupOutdatedCaches: true,
      maximumFileSizeToCacheInBytes: 3 * 1024 * 1024
    },
    devOptions: { enabled: false }
  })],
  test: { environment: 'node', include: ['tests/**/*.test.ts'], setupFiles: ['./tests/setup.ts'] }
});
