import type { CalendarEvent, Withdrawal } from '../domain/model';

export function shareEvents(events: CalendarEvent[]): CalendarEvent[] {
  return events.filter(e => e.visibility === 'shared').map(e => e.deletedAt ? {
    ...e, title: '삭제된 일정', description: '', startAt: '2000-01-01', endAt: '2000-01-02',
    allDay: true, recurrenceRule: null
  } : e);
}
export function shareWithdrawals(records: Withdrawal[]): Withdrawal[] {
  return records.map(({ id, clock, version, createdAt, updatedAt, updatedBy, deletedAt, ownerId }) => ({
    id, clock, version, createdAt, updatedAt, updatedBy, deletedAt, ownerId
  }));
}
