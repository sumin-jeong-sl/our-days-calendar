import { useState } from 'react';

export function SharePin({ value, onChange, label = '공유 PIN', allowLegacy = false }: { value: string; onChange: (value: string) => void; label?: string; allowLegacy?: boolean }) {
  const [legacy, setLegacy] = useState(false);
  return <div><label>{legacy ? '이전 파일의 기존 암호' : label}<input type="password" inputMode={legacy ? 'text' : 'numeric'} pattern={legacy ? undefined : '[0-9]{4}'} maxLength={legacy ? 200 : 4} value={value} onChange={e => onChange(legacy ? e.target.value : e.target.value.replace(/[^0-9]/g, '').slice(0, 4))} placeholder={legacy ? '기존 긴 암호' : '숫자 4자리'} autoComplete="off" /></label>{allowLegacy && <button className="text-button" type="button" onClick={() => { setLegacy(!legacy); onChange(''); }}>{legacy ? '숫자 PIN 사용' : '이전 긴 암호로 가져오기'}</button>}</div>;
}
