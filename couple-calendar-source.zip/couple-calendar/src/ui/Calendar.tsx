import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { addDays, dateTime, formatDate, milestones, occurrences, onDate, today, type Occurrence } from '../domain/dates';
import type { Snapshot } from '../domain/model';
import { Empty, EventList } from './shared';

export function Calendar({ snapshot, onAdd, onEdit }: { snapshot: Snapshot; onAdd: (date: string) => void; onEdit: (item: Occurrence) => void }) {
  const [selected, setSelected] = useState(today());
  const [month, setMonth] = useState(dateTime(today()).startOf('month'));
  const [view, setView] = useState<'month' | 'week' | 'day'>('month');
  const [filter, setFilter] = useState('all');
  const from = view === 'month' ? month.minus({ days: month.weekday % 7 }).toISODate()! : view === 'week' ? dateTime(selected).minus({ days: dateTime(selected).weekday % 7 }).toISODate()! : selected;
  const count = view === 'month' ? 42 : view === 'week' ? 7 : 1;
  const days = Array.from({ length: count }, (_, i) => addDays(from, i));
  const events = snapshot.events.filter(e => (e.visibility === 'shared' || e.ownerId === snapshot.config.currentUserId) && (filter === 'all' || (filter === 'together' ? e.category === 'together' : e.ownerId === filter && e.category === 'personal')));
  const items = useMemo(() => occurrences(events, from, days.at(-1)!), [snapshot, filter, from, count]);
  const special = milestones(snapshot.config.couple, snapshot.anniversaries, from, days.at(-1)!);
  const selectedItems = view === 'week' ? items : onDate(items, selected);
  const selectedMilestones = special.filter(m => view === 'week' || m.date === selected);
  const move = (direction: number) => {
    if (view === 'month') { const next = month.plus({ months: direction }); setMonth(next); setSelected(next.toISODate()!); }
    else { const next = addDays(selected, direction * (view === 'week' ? 7 : 1)); setSelected(next); setMonth(dateTime(next).startOf('month')); }
  };
  return <div className="page calendar-page"><div className="page-title"><div><p className="eyebrow">CALENDAR</p><h1>캘린더</h1></div><button className="icon-button accent" aria-label="일정 추가" onClick={() => onAdd(selected)}><Plus /></button></div>
    <div className="segmented view-switch">{(['month', 'week', 'day'] as const).map((v, i) => <button key={v} className={view === v ? 'selected' : ''} onClick={() => setView(v)}>{['월간', '주간', '일간'][i]}</button>)}</div>
    <div className="calendar-card"><div className="calendar-toolbar"><button className="icon-button" aria-label="이전 기간" onClick={() => move(-1)}><ChevronLeft size={20} /></button><h2>{view === 'month' ? month.toFormat('yyyy년 M월') : view === 'week' ? `${formatDate(from, 'M.d')} – ${formatDate(days.at(-1)!, 'M.d')}` : formatDate(selected, 'M월 d일')}</h2><button className="icon-button" aria-label="다음 기간" onClick={() => move(1)}><ChevronRight size={20} /></button></div>
      {view !== 'day' && <><div className="weekdays">{['일', '월', '화', '수', '목', '금', '토'].map(d => <span key={d}>{d}</span>)}</div><div className="calendar-grid">{days.map(date => {
        const day = dateTime(date), dayItems = onDate(items, date), anniversary = special.some(m => m.date === date);
        return <button key={date} className={`calendar-day ${day.month !== month.month && view === 'month' ? 'muted' : ''} ${date === selected ? 'active' : ''} ${date === today() ? 'is-today' : ''}`} aria-label={`${formatDate(date)} ${dayItems.length}개 일정${anniversary ? ', 기념일' : ''}`} aria-pressed={date === selected} onClick={() => setSelected(date)}><span>{day.day}</span><div className="day-dots">{dayItems.slice(0, 3).map(item => <i key={item.key} style={{ background: item.event.color }} />)}{anniversary && <b>♥</b>}</div></button>;
      })}</div></>}
      <div className="calendar-footer"><span><i /> 오늘</span><button className="text-button" onClick={() => { setSelected(today()); setMonth(dateTime(today()).startOf('month')); }}>오늘로 이동</button></div>
    </div>
    <div className="filter-chips"><button className={filter === 'all' ? 'selected' : ''} onClick={() => setFilter('all')}>전체</button><button className={filter === 'together' ? 'selected' : ''} onClick={() => setFilter('together')}>함께</button>{snapshot.config.users.map(u => <button key={u.id} className={filter === u.id ? 'selected' : ''} onClick={() => setFilter(u.id)}><i style={{ background: u.color }} />{u.nickname}</button>)}</div>
    <div className="section-title"><h2>{view === 'week' ? '이번 주의 일정' : formatDate(selected)}</h2><span className="count-label">{selectedItems.length}개의 일정</span></div>
    {selectedMilestones.map(m => <div className="milestone-mini" key={m.id}><span>♥</span><strong>{m.title}</strong><small>{view === 'week' ? formatDate(m.date, 'M.d') : '기념일'}</small></div>)}
    {selectedItems.length ? <div className="card">{view === 'week' ? days.map(date => { const list = onDate(items, date); return list.length ? <div key={date}><h3 className="agenda-date">{formatDate(date)}</h3><EventList items={list} config={snapshot.config} onEdit={onEdit} /></div> : null; }) : <EventList items={selectedItems} config={snapshot.config} onEdit={onEdit} />}</div> : <Empty title="등록된 일정 없음">선택한 날짜에 일정을 추가하세요.</Empty>}
    <button className="outline-button full" onClick={() => onAdd(selected)}><Plus size={18} /> 이 날에 일정 추가</button>
  </div>;
}
