import { DateTime } from 'luxon';
import type { Anniversary, CalendarEvent, Couple } from './model';

export const ZONE = 'Asia/Seoul';
export const today = () => DateTime.now().setZone(ZONE).toISODate()!;
export const dateTime = (date: string) => DateTime.fromISO(date, { zone: ZONE });
export const formatDate = (date: string, format = 'M월 d일 cccc') => dateTime(date).setLocale('ko').toFormat(format);
export const addDays = (date: string, days: number) => dateTime(date).plus({ days }).toISODate()!;
export const daysBetween = (a: string, b: string) => Math.round(dateTime(b).startOf('day').diff(dateTime(a).startOf('day'), 'days').days);
export const daysTogether = (start: string | null, now = today()) => start ? daysBetween(start, now) + 1 : null;
export interface Occurrence { key: string; event: CalendarEvent; start: DateTime; end: DateTime; date: string; }

export function occurrences(events: CalendarEvent[], from: string, to: string): Occurrence[] {
  const results: Occurrence[] = [];
  const rangeStart = dateTime(from), rangeEnd = dateTime(to).plus({ days: 1 });
  for (const event of events) {
    if (event.deletedAt) continue;
    const original = DateTime.fromISO(event.startAt, { zone: event.timeZone }).setZone(event.timeZone);
    const end = DateTime.fromISO(event.endAt, { zone: event.timeZone }).setZone(event.timeZone);
    const duration = end.diff(original).as('milliseconds');
    const dayDuration = end.startOf('day').diff(original.startOf('day'), 'days').days;
    const rule = event.recurrenceRule;
    const emit = (start: DateTime) => {
      const finish = event.allDay ? start.plus({ days: dayDuration }) : start.plus({ milliseconds: duration });
      if (finish > rangeStart && start < rangeEnd) results.push({ key: event.id + ':' + start.toISO(), event, start, end: finish, date: start.setZone(ZONE).toISODate()! });
    };
    if (!rule) { emit(original); continue; }
    const earliest = rangeStart.minus({ milliseconds: duration });
    let index = 0;
    if (rule.frequency === 'daily') index = Math.max(0, Math.floor(earliest.diff(original, 'days').days) - 1);
    if (rule.frequency === 'weekly') index = Math.max(0, Math.floor(earliest.diff(original, 'weeks').weeks) - 1);
    if (rule.frequency === 'monthly') index = Math.max(0, Math.floor(earliest.diff(original, 'months').months) - 1);
    if (rule.frequency === 'yearly') index = Math.max(0, earliest.year - original.year - 1);
    // Each visible query spans at most one calendar year in the UI.
    for (let step = 0; step < 1000; step++, index++) {
      const start = original.plus(rule.frequency === 'daily' ? { days: index } : rule.frequency === 'weekly' ? { weeks: index } : rule.frequency === 'monthly' ? { months: index } : { years: index });
      if (start >= rangeEnd || (rule.until && start.toISODate()! > rule.until)) break;
      if ((rule.frequency === 'monthly' || rule.frequency === 'yearly') && start.day !== original.day) continue;
      emit(start);
    }
  }
  return results.sort((a, b) => a.start.toMillis() - b.start.toMillis() || a.event.title.localeCompare(b.event.title));
}
export const onDate = (items: Occurrence[], date: string) => {
  const start = dateTime(date), end = start.plus({ days: 1 });
  return items.filter(item => item.start < end && item.end > start);
};
export interface Milestone { id: string; title: string; date: string; kind: 'relationship' | 'custom'; }
export function milestones(couple: Couple, anniversaries: Anniversary[], from: string, to: string): Milestone[] {
  const result: Milestone[] = [];
  if (couple.anniversaryDate) {
    const start = dateTime(couple.anniversaryDate);
    const first = Math.max(1, Math.ceil((daysBetween(couple.anniversaryDate, from) + 1) / 100));
    for (let n = first; n <= first + 5; n++) {
      const date = start.plus({ days: n * 100 - 1 }).toISODate()!;
      if (date > to) break;
      if (date >= from) result.push({ id: 'day-' + n, title: `함께한 ${n * 100}일`, date, kind: 'relationship' });
    }
    for (let year = dateTime(from).year; year <= dateTime(to).year; year++) {
      const n = year - start.year;
      if (n < 1) continue;
      // A Feb 29 relationship anniversary falls on Feb 28 in non-leap years.
      const date = start.plus({ years: n }).toISODate()!;
      if (date >= from && date <= to) result.push({ id: 'year-' + year, title: `${n}주년 기념일`, date, kind: 'relationship' });
    }
  }
  for (const item of anniversaries) {
    if (item.deletedAt) continue;
    if (item.repeatType === 'once') {
      if (item.date >= from && item.date <= to) result.push({ id: item.id, title: item.title, date: item.date, kind: 'custom' });
    } else {
      const original = dateTime(item.date);
      for (let year = dateTime(from).year; year <= dateTime(to).year; year++) {
        if (year < original.year) continue;
        const date = original.plus({ years: year - original.year }).toISODate()!;
        if (date >= from && date <= to) result.push({ id: `${item.id}-${year}`, title: item.title, date, kind: 'custom' });
      }
    }
  }
  return result.sort((a, b) => a.date.localeCompare(b.date));
}
