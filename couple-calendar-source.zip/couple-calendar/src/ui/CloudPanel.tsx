import { useState, useSyncExternalStore } from 'react';
import { Cloud, Link2 } from 'lucide-react';
import { cloudStatus, storedConnection, createCloudConnection, joinCloudConnection, disconnectCloud, startCloudSync } from '../sync/cloud';
import { connectionLink, parseConnectionLink, firebaseConfigSchema } from '../sync/cloudCrypto';

export function CloudPanel({ joinOnly = false }: { joinOnly?: boolean }) {
  const status = useSyncExternalStore(cloudStatus.subscribe, cloudStatus.get);
  const [invite, setInvite] = useState(() => location.hash.startsWith('#connect=') ? location.href : '');
  const [config, setConfig] = useState(''), [link, setLink] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const connected = storedConnection();
  const handle = async (work: () => Promise<void>) => { setBusy(true); setError(''); try { await work(); } catch (err) { setError((err as Error).message); } finally { setBusy(false); } };
  return <section className="card settings-card"><div className="card-label"><Cloud size={18} /><h2>자동 일정 공유</h2></div><p>일정을 저장하면 자동으로 전송합니다. 상대방이 앱을 열고 인터넷에 연결되어 있으면 변경사항을 받습니다. 비공개 일정은 전송하지 않습니다.</p>
    {connected ? <><p className="status-note" role="status">{status.message}</p>{status.lastSentAt && <p className="hint">최근 업로드: {new Date(status.lastSentAt).toLocaleString('ko-KR')}</p>}
      <button className="outline-button full" disabled={busy} onClick={() => setLink(connectionLink(connected))}><Link2 size={17} /> 상대방 연결 링크 표시</button>
      <button className="text-button" disabled={busy} onClick={() => void handle(startCloudSync)}>다시 연결</button>
      <button className="text-button" disabled={busy} onClick={() => { disconnectCloud(); setLink(''); }}>이 기기 자동 공유 끄기</button><p className="hint">자동 공유를 꺼도 이 기기의 일정과 서버의 기존 사본은 유지됩니다.</p>
    </> : <>
      {!joinOnly && <button className="primary-button full" disabled={busy} onClick={() => void handle(async () => {
        const value = config.trim() ? JSON.parse(config) : await (await fetch(new URL('sync-config.json', document.baseURI))).json();
        if (!value) throw new Error('무료 동기화 서비스 설정이 아직 완료되지 않았습니다.');
        setLink(connectionLink(await createCloudConnection(firebaseConfigSchema.parse(value))));
      })}>자동 공유 시작</button>}
      <label>상대방 연결 링크<textarea value={invite} onChange={e => setInvite(e.target.value)} placeholder="상대방이 보낸 링크를 붙여넣으세요" rows={2} /></label>
      <button className="outline-button full" disabled={busy || !invite.trim()} onClick={() => void handle(async () => { await joinCloudConnection(parseConnectionLink(invite)); setInvite(''); history.replaceState(null, '', location.pathname + location.search); })}>연결 링크로 참여</button>
      {!joinOnly && <details><summary>관리자 연결 설정</summary><p className="hint">기본 설정이 없는 배포에서는 README에 따라 Firebase Spark 프로젝트를 설정하고 웹 앱 설정 JSON을 입력합니다. 결제 계정을 연결할 필요가 없습니다.</p><label>Firebase 웹 앱 설정<textarea value={config} onChange={e => setConfig(e.target.value)} rows={4} placeholder='{"apiKey": "...", "projectId": "...", "databaseURL": "...", "appId": "..."}' /></label></details>}
    </>}
    {link && <><label>두 사람 연결 링크<textarea readOnly value={link} rows={3} /></label><button className="outline-button full" onClick={() => void handle(async () => { await navigator.clipboard.writeText(link); })}>링크 복사</button><p className="hint">연결 링크에는 접근 정보가 들어 있습니다. 상대방에게만 보내세요. 한 연결에 두 기기만 참여할 수 있습니다.</p></>}
    {error && <p className="error" role="alert">{error}</p>}
  </section>;
}
