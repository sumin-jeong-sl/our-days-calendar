import { useRef, useState } from 'react';
import { ArrowDownToLine, ArrowUpFromLine, Check, FileLock2, FolderHeart, HardDrive, ShieldCheck } from 'lucide-react';
import type { Payload, Snapshot } from '../domain/model';
import { repository } from '../storage/repository';
import { requestPersistence } from '../storage/database';
import { encryptPayload, parseFile, saveFile, secretHash } from '../sync/files';
import { today } from '../domain/dates';

export function Settings({ snapshot, onImport, notify, onConflicts }: { snapshot: Snapshot; onImport: (payload: Payload, hash: string | null) => void; notify: (message: string) => void; onConflicts: () => void }) {
  const [password, setPassword] = useState(''), [busy, setBusy] = useState(false);
  const [name, setName] = useState(snapshot.config.couple.name), [date, setDate] = useState(snapshot.config.couple.anniversaryDate ?? '');
  const [error, setError] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const { config } = snapshot;
  const currentUser = config.users.find(u => u.id === config.currentUserId)!;
  const handle = async (action: () => Promise<void>) => {
    setBusy(true); setError('');
    try { await action(); } catch (err) { setError((err as Error).message); } finally { setBusy(false); }
  };
  const exportFile = (kind: 'backup' | 'share') => handle(async () => {
    if (kind === 'backup' && !window.confirm('전체 백업에는 비공개 일정이 포함됩니다. 개인 보관용으로 저장할까요? 상대방에게 보낼 때는 공유 파일을 사용하세요.')) return;
    const hash = kind === 'share' ? await secretHash(password) : null;
    if (hash) await repository.checkSecret(hash);
    const payload = await repository.createPayload(kind);
    const text = kind === 'share' ? await encryptPayload(payload, password) : JSON.stringify(payload, null, 2);
    await saveFile(text, `our-days-${kind}-${today()}.json`);
    await repository.markExported(kind, hash, config.revision);
    notify(kind === 'backup' ? '백업 파일을 보관해 주세요. 파일 앱에서 저장 여부를 확인하세요.' : '공유 파일을 준비했어요. 상대방이 가져와야 반영됩니다.');
    setPassword('');
  });
  return <div className="page settings-page"><div className="page-title"><div><p className="eyebrow">KEEP OUR MEMORIES</p><h1>설정과 보관</h1></div><FolderHeart className="page-icon" size={30} /></div>
    <div className="identity-card"><span className="avatar" style={{ background: currentUser.color + '22', color: currentUser.color }}>{currentUser.nickname.slice(0, 1)}</span><div><strong>{currentUser.nickname}의 아이폰 공간</strong><p>두 사람만의 캘린더 · 로컬 저장</p></div><ShieldCheck size={22} /></div>
    <section className="card settings-card"><div className="card-label"><FileLock2 size={18} /><h2>두 사람의 일정 공유</h2></div><p>암호화한 파일을 AirDrop·메신저 등으로 보내고, 상대방이 이 앱에서 가져오면 반영됩니다. 자동 동기화는 사용하지 않습니다.</p>
      <label>두 사람의 공유 암호<input type="password" placeholder="처음 정한 동일한 암호 · 12자 이상" minLength={12} maxLength={200} value={password} onChange={e => setPassword(e.target.value)} autoComplete="off" /></label><p className="hint">첫 교환에서 연결 암호가 정해집니다. 암호는 파일과 별도로 전달하고 안전한 곳에 보관하세요.</p>
      <button className="primary-button full" onClick={() => exportFile('share')} disabled={busy}><ArrowUpFromLine size={17} /> 연결·공유 파일 만들기</button>
      <button className="outline-button full" onClick={() => fileInput.current?.click()} disabled={busy}><ArrowDownToLine size={17} /> 공유 파일 또는 백업 가져오기</button>
      <input ref={fileInput} type="file" accept=".json,application/json" hidden onChange={e => { const file = e.target.files?.[0]; e.target.value = ''; if (file) void handle(async () => { const parsed = await parseFile(file, password); onImport(parsed.payload, parsed.hash); setPassword(''); }); }} />
      <div className="status-note"><span className={`status-dot ${snapshot.conflicts.length ? 'warning' : ''}`} /><span>{snapshot.conflicts.length ? `충돌 ${snapshot.conflicts.length}건 · 선택 필요` : config.syncStatus === 'exported' ? '공유 파일 준비됨 · 상대방 가져오기 필요' : config.syncStatus === 'imported' ? '최근 파일 반영됨 · 다음 변경은 다시 교환' : '이 기기에 저장됨 · 파일 교환 대기'}</span></div>
      {config.lastSyncAt && <p className="hint">최근 가져오기: {new Date(config.lastSyncAt).toLocaleString('ko-KR')}</p>}
      {!!snapshot.conflicts.length && <button className="text-button" onClick={onConflicts}>동시 수정 충돌 해결하기 →</button>}
      <p className="hint">공유 해제·삭제도 다음 파일 교환 때 반영됩니다. 상대방이 이미 받은 파일까지 회수할 수는 없습니다.</p>
    </section>
    <section className="card settings-card"><div className="card-label"><HardDrive size={18} /><h2>기억을 안전하게 보관하기</h2></div><p>전체 JSON 백업을 파일 앱이나 iCloud Drive에 직접 저장해 주세요. 전체 백업에는 비공개 일정도 들어 있습니다.</p><button className="outline-button full" onClick={() => exportFile('backup')} disabled={busy}><ArrowUpFromLine size={17} /> 전체 백업 저장</button><p className="hint">{config.lastBackupAt ? `최근 백업 내보내기: ${new Date(config.lastBackupAt).toLocaleDateString('ko-KR')}` : '아직 백업을 내보내지 않았어요.'}</p><button className="text-button" disabled={busy} onClick={() => void handle(async () => { const persistent = await requestPersistence(); notify(persistent ? '저장소 지속성이 허용되었습니다. 별도 파일 백업도 보관해 주세요.' : '브라우저가 지속성을 허용하지 않았습니다. 파일 백업을 보관해 주세요.'); })}>저장소 보호 요청</button><p className="hint">저장소 지속성 요청도 영구 보관을 보장하지 않습니다. 앱 제거·사이트 데이터 삭제·기기 변경 전에는 백업이 필요합니다.</p></section>
    <section className="card settings-card"><div className="card-label"><FolderHeart size={18} /><h2>우리의 공간</h2></div><form className="form" onSubmit={e => { e.preventDefault(); void handle(async () => { await repository.updateCouple(name.trim(), date || null); notify('공간 정보를 저장했어요. 다음 공유 파일에 포함됩니다.'); }); }}><label>커플 이름<input value={name} onChange={e => setName(e.target.value)} required maxLength={60} /></label><label>연애 시작일<input type="date" value={date} onChange={e => setDate(e.target.value)} /></label><button className="outline-button full" disabled={busy}><Check size={16} /> 공간 정보 저장</button></form></section>
    <section className="install-note"><h2>아이폰 홈 화면에 추가하기</h2><ol><li>Safari에서 이 앱의 HTTPS 주소를 열어요.</li><li>공유 메뉴 → 홈 화면에 추가 → 웹 앱으로 열기.</li><li>설치한 앱을 열고, 기존 데이터가 있다면 백업을 가져와요.</li></ol><p>Safari 탭과 설치된 앱은 별도 저장 공간일 수 있습니다. 설치·주소 변경 전 백업을 먼저 저장하세요. 스플래시 화면과 권한 표시는 iOS 버전에 따라 달라집니다.</p></section>
    {error && <p className="error" role="alert">{error}</p>}
    <p className="app-footnote">우리의 날들 · v1.0<br />광고 없이, 두 사람의 기기에 먼저 저장합니다.</p>
  </div>;
}
