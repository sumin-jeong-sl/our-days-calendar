import { describe, expect, it } from 'vitest';
import { CalendarDatabase } from '../src/storage/database';
import { CalendarRepository } from '../src/storage/repository';
import { randomSecret, sealCloud, openCloud, connectionLink, parseConnectionLink, payloadFingerprint } from '../src/sync/cloudCrypto';
import { secretHash } from '../src/sync/files';

describe('automatic sharing payload and credentials', () => {
  it('uses a random key distinct from the four-digit PIN and validates invitations', async () => {
    const a = new CalendarDatabase('cloud-' + crypto.randomUUID()), repo = new CalendarRepository(a);
    await repo.setup('test', 'A', 'B', null);
    const p = await repo.createPayload('share'); if (p.kind !== 'share') throw new Error();
    const key = randomSecret(), room = randomSecret(); expect(key).toHaveLength(64); expect(room).not.toBe(key);
    const cipher = await sealCloud(p, key); expect(cipher).not.toContain('nickname');
    expect(await openCloud(cipher, key)).toEqual(p);
    await expect(openCloud(cipher, randomSecret())).rejects.toThrow();
    const c = { firebase: { apiKey: 'a'.repeat(30), projectId: 'test', appId: 'test-app', databaseURL: 'https://test.firebaseio.com' }, key, room, coupleId: p.couple.id };
    expect(parseConnectionLink(connectionLink(c, 'https://example.com/app/'))).toEqual(c);
    expect(() => parseConnectionLink('https://example.com/#connect=1234')).toThrow();
    expect(payloadFingerprint(p)).toBe(payloadFingerprint({ ...p, exportedAt: '2026-10-14T10:00:00Z' }));
    await a.delete();
  });
  it('pairs and merges automatic changes without changing the file PIN', async () => {
    const a = new CalendarDatabase('cloud-' + crypto.randomUUID()), b = new CalendarDatabase('cloud-' + crypto.randomUUID());
    const ra = new CalendarRepository(a), rb = new CalendarRepository(b);
    await ra.setup('test', 'A', 'B', null); await rb.importPayload(await ra.createPayload('share'), null, 'automatic');
    await rb.changeSharePin(null, await secretHash('0123'));
    const ownerId = (await ra.snapshot())!.config.currentUserId;
    await ra.saveEvent({ title: 'shared', description: '', startAt: '2026-10-14', endAt: '2026-10-15', allDay: true, timeZone: 'Asia/Seoul', ownerId, visibility: 'shared', category: 'together', color: '#c97987', recurrenceRule: null });
    await rb.importPayload(await ra.createPayload('share'), null, 'automatic');
    expect((await rb.snapshot())!.events[0].title).toBe('shared'); expect((await rb.snapshot())!.config.shareSecretHash).toBe(await secretHash('0123'));
    await expect(rb.importPayload(await ra.createPayload('share'), null)).rejects.toThrow('암호화');
    await a.delete(); await b.delete();
  });
});
