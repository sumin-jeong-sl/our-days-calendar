import { db, type CalendarDatabase } from './database';
import { anniversarySchema, coupleSchema, eventSchema, newVersion, payloadSchema, type Anniversary, type AppConfig, type CalendarEvent, type Clock, type Couple, type EntityKind, type Payload, type RecordValue, type Snapshot, type User, type Withdrawal } from '../domain/model';
import { compareClocks, joinClocks, mergeRecord, revise } from '../domain/merge';
import { shareEvents, shareWithdrawals } from '../sync/projection';

export class CalendarRepository {
  constructor(private database: CalendarDatabase = db) {}
  async snapshot(): Promise<Snapshot | null> {
    return this.database.transaction('r', this.database.tables, async () => {
      const config = (await this.database.meta.get('config'))?.value;
      if (!config) return null;
      return { config, events: await this.database.events.toArray(), anniversaries: await this.database.anniversaries.toArray(), withdrawals: await this.database.withdrawals.toArray(), conflicts: await this.database.conflicts.toArray() };
    });
  }
  async setup(name: string, me: string, partner: string, startDate: string | null) {
    const deviceId = crypto.randomUUID();
    const userA: User = { ...newVersion(deviceId), nickname: me.trim(), color: '#c97987' };
    const userB: User = { ...newVersion(deviceId), nickname: partner.trim(), color: '#729c94' };
    const couple: Couple = { ...newVersion(deviceId), name: name.trim(), anniversaryDate: startDate };
    const config: AppConfig = { couple, users: [userA, userB], currentUserId: userA.id, deviceId, revision: 0, lastExportRevision: 0, lastSyncAt: null, lastBackupAt: null, syncStatus: 'local', shareSecretHash: null };
    // Use the same validation rules used for incoming files.
    payloadSchema.parse({ app: 'our-days', schemaVersion: 1, kind: 'backup', exportedAt: new Date().toISOString(), couple, users: config.users, currentUserId: userA.id, shareSecretHash: null, events: [], anniversaries: [], withdrawals: [], conflicts: [] });
    await this.database.transaction('rw', this.database.meta, async () => {
      if (await this.database.meta.get('config')) throw new Error('이미 설정된 공간입니다.');
      await this.database.meta.put({ key: 'config', value: config });
    });
  }
  private async config() {
    const value = (await this.database.meta.get('config'))?.value;
    if (!value) throw new Error('먼저 두 사람의 공간을 만들어 주세요.');
    return value;
  }
  private async changed(config: AppConfig) {
    config.revision++;
    config.syncStatus = 'local';
    await this.database.meta.put({ key: 'config', value: config });
  }
  async saveEvent(input: Omit<CalendarEvent, 'clock' | 'version' | 'createdAt' | 'updatedAt' | 'deletedAt' | 'updatedBy' | 'id'>, id?: string, expectedClock?: Clock) {
    await this.database.transaction('rw', this.database.tables, async () => {
      const config = await this.config(), existing = id ? await this.database.events.get(id) : undefined;
      if (existing?.visibility === 'private' && existing.ownerId !== config.currentUserId) throw new Error('상대방의 비공개 일정은 수정할 수 없습니다.');
      if (existing && expectedClock && compareClocks(existing.clock, expectedClock) !== 'equal') throw new Error('다른 화면에서 일정이 변경되었습니다. 닫고 다시 열어 주세요.');
      if (input.visibility === 'private' && input.ownerId !== config.currentUserId) throw new Error('내 일정만 비공개로 설정할 수 있습니다.');
      if (existing && input.ownerId !== existing.ownerId) throw new Error('일정의 작성자는 변경할 수 없습니다.');
      if (!existing && input.ownerId !== config.currentUserId) throw new Error('새 일정의 작성자는 현재 사용자여야 합니다.');
      if ((await this.database.conflicts.where('entityId').equals(existing?.id ?? '').count()) > 0) throw new Error('이 일정의 충돌을 먼저 해결해 주세요.');
      const priorWithdrawal = existing ? await this.database.withdrawals.get(existing.id) : undefined;
      const editable = { title: input.title, description: input.description, startAt: input.startAt, endAt: input.endAt, allDay: input.allDay, timeZone: input.timeZone, ownerId: input.ownerId, visibility: input.visibility, category: input.category, color: input.color, recurrenceRule: input.recurrenceRule };
      const record = eventSchema.parse({ ...(existing ? revise(existing, config.deviceId, priorWithdrawal?.clock) : newVersion(config.deviceId)), ...editable, deletedAt: null });
      if (existing?.visibility === 'shared' && record.visibility === 'private') {
        const withdrawal: Withdrawal = { ...record, ownerId: record.ownerId, deletedAt: record.updatedAt };
        await this.database.withdrawals.put(withdrawal);
      }
      await this.database.events.put(record); await this.changed(config);
    });
  }
  async deleteEvent(id: string, expectedClock?: Clock) {
    await this.database.transaction('rw', this.database.tables, async () => {
      const config = await this.config(), event = await this.database.events.get(id);
      if (!event) return;
      if (event.visibility === 'private' && event.ownerId !== config.currentUserId) throw new Error('비공개 일정에 접근할 수 없습니다.');
      if (expectedClock && compareClocks(event.clock, expectedClock) !== 'equal') throw new Error('일정이 변경되었습니다. 다시 열어 주세요.');
      if (await this.database.conflicts.where('entityId').equals(id).count()) throw new Error('이 일정의 충돌을 먼저 해결해 주세요.');
      const deleted = revise(event, config.deviceId);
      deleted.deletedAt = deleted.updatedAt;
      await this.database.events.put(deleted); await this.changed(config);
    });
  }
  async saveAnniversary(input: Pick<Anniversary, 'title' | 'date' | 'repeatType'>, id?: string) {
    await this.database.transaction('rw', this.database.tables, async () => {
      const config = await this.config(), old = id ? await this.database.anniversaries.get(id) : undefined;
      if (old && await this.database.conflicts.where('entityId').equals(old.id).count()) throw new Error('기념일 충돌을 먼저 해결해 주세요.');
      await this.database.anniversaries.put(anniversarySchema.parse({ ...(old ? revise(old, config.deviceId) : newVersion(config.deviceId)), ...input, deletedAt: null }));
      await this.changed(config);
    });
  }
  async deleteAnniversary(id: string) {
    await this.database.transaction('rw', this.database.tables, async () => {
      const config = await this.config(), old = await this.database.anniversaries.get(id);
      if (!old) return;
      if (await this.database.conflicts.where('entityId').equals(id).count()) throw new Error('기념일 충돌을 먼저 해결해 주세요.');
      const deleted = revise(old, config.deviceId); deleted.deletedAt = deleted.updatedAt;
      await this.database.anniversaries.put(deleted); await this.changed(config);
    });
  }
  async updateCouple(name: string, anniversaryDate: string | null) {
    await this.database.transaction('rw', this.database.tables, async () => {
      const config = await this.config();
      if (await this.database.conflicts.where('entityId').equals(config.couple.id).count()) throw new Error('공간 설정 충돌을 먼저 해결해 주세요.');
      config.couple = coupleSchema.parse({ ...revise(config.couple, config.deviceId), name, anniversaryDate });
      await this.changed(config);
    });
  }
  async createPayload(kind: 'backup' | 'share'): Promise<Payload> {
    const s = await this.snapshot(); if (!s) throw new Error('먼저 공간을 만들어 주세요.');
    const common = { app: 'our-days' as const, schemaVersion: 1 as const, exportedAt: new Date().toISOString(), couple: s.config.couple, users: s.config.users, anniversaries: s.anniversaries, withdrawals: s.withdrawals };
    if (kind === 'backup') return payloadSchema.parse({ ...common, kind, currentUserId: s.config.currentUserId, shareSecretHash: s.config.shareSecretHash, events: s.events, conflicts: s.conflicts });
    if (s.conflicts.length) throw new Error('동시 수정 충돌을 해결한 뒤 공유해 주세요. 전체 백업은 지금도 가능합니다.');
    // Deletes retain only the minimum scheduling placeholder, never the former content.
    const events = shareEvents(s.events);
    // Whitelist withdrawals: private titles/descriptions must never be serialized.
    const withdrawals = shareWithdrawals(s.withdrawals);
    return payloadSchema.parse({ ...common, kind, senderId: s.config.currentUserId, events, withdrawals });
  }
  async checkSecret(hash: string) {
    const config = await this.config();
    if (config.shareSecretHash && config.shareSecretHash !== hash) throw new Error('처음 연결할 때 정한 공유 암호를 입력해 주세요.');
  }
  async markExported(kind: 'backup' | 'share', hash: string | null, revision: number) {
    await this.database.transaction('rw', this.database.meta, async () => {
      const config = await this.config();
      if (kind === 'backup') config.lastBackupAt = new Date().toISOString();
      else { config.lastExportRevision = revision; config.syncStatus = config.revision === revision ? 'exported' : 'local'; config.shareSecretHash = hash; }
      await this.database.meta.put({ key: 'config', value: config });
    });
  }
  async importPayload(raw: Payload, hash: string | null): Promise<{ added: number; conflicts: number; paired: boolean }> {
    const payload = payloadSchema.parse(raw);
    if (payload.kind === 'share' && !hash) throw new Error('암호화된 공유 파일만 가져올 수 있습니다.');
    return this.database.transaction('rw', this.database.tables, async () => {
      let config = (await this.database.meta.get('config'))?.value;
      let paired = false, added = 0, conflictCount = 0;
      if (config && config.couple.id !== payload.couple.id) {
        const hasData = await this.database.events.count() || await this.database.anniversaries.count() || await this.database.conflicts.count() || await this.database.withdrawals.count();
        if (hasData) throw new Error('다른 커플의 파일입니다. 기존 데이터를 덮어쓰지 않았습니다. 새 브라우저 공간에서 가져와 주세요.');
      }
      if (!config || config.couple.id !== payload.couple.id) {
        const currentUserId = payload.kind === 'backup' ? payload.currentUserId : payload.users.find(u => u.id !== payload.senderId)!.id;
        config = { couple: payload.couple, users: payload.users, currentUserId, deviceId: crypto.randomUUID(), revision: 0, lastExportRevision: 0, lastBackupAt: null, lastSyncAt: null, syncStatus: 'local', shareSecretHash: payload.kind === 'share' ? hash : payload.shareSecretHash };
        paired = true;
      } else {
        if (payload.users.some(u => !config!.users.some(local => local.id === u.id))) throw new Error('연결된 사용자 정보와 다릅니다.');
        if (payload.kind === 'share' && config.shareSecretHash && config.shareSecretHash !== hash) throw new Error('연결 암호가 다른 파일입니다.');
        if (payload.kind === 'share' && payload.senderId === config.currentUserId) throw new Error('내가 보낸 파일입니다. 상대방의 공유 파일을 가져와 주세요.');
      }
      const apply = async <T extends RecordValue>(kind: EntityKind, local: T | undefined, remote: T) => {
        const result = mergeRecord(local, remote, kind);
        if (result.conflict) {
          if (!(await this.database.conflicts.get(result.conflict.id))) { await this.database.conflicts.put(result.conflict); conflictCount++; }
        }
        if (result.changed) added++;
        return result.record;
      };
      config.couple = await apply('couple', config.couple, payload.couple);
      config.users = [await apply('user', config.users[0], payload.users.find(u => u.id === config!.users[0].id)!), await apply('user', config.users[1], payload.users.find(u => u.id === config!.users[1].id)!)];
      // Process privacy withdrawals first. Never overwrite a locally private event with incoming shared content.
      for (const remote of payload.withdrawals) {
        const old = await this.database.withdrawals.get(remote.id);
        const clock = joinClocks(old?.clock ?? {}, remote.clock);
        await this.database.withdrawals.put({ ...remote, clock });
        const existing = await this.database.events.get(remote.id);
        if (existing?.visibility === 'shared' && compareClocks(existing.clock, remote.clock) !== 'after') {
          await this.database.events.put({ ...existing, title: '공유가 해제된 일정', description: '', deletedAt: remote.deletedAt, clock: joinClocks(existing.clock, remote.clock), updatedAt: remote.updatedAt }); added++;
          await this.database.conflicts.where('entityId').equals(remote.id).delete();
        }
      }
      for (const remote of payload.events) {
        const local = await this.database.events.get(remote.id);
        if (payload.kind === 'share' && local?.visibility === 'private') continue;
        const withdrawal = await this.database.withdrawals.get(remote.id);
        if (payload.kind === 'share' && withdrawal && compareClocks(remote.clock, withdrawal.clock) !== 'after') continue;
        const record = await apply('event', local, remote);
        await this.database.events.put(record);
      }
      for (const remote of payload.anniversaries) await this.database.anniversaries.put(await apply('anniversary', await this.database.anniversaries.get(remote.id), remote));
      if (payload.kind === 'backup') for (const conflict of payload.conflicts) {
        const local = await this.database.events.get(conflict.entityId);
        const privateShare = local?.visibility === 'private' && (('visibility' in conflict.local && conflict.local.visibility === 'shared') || ('visibility' in conflict.remote && conflict.remote.visibility === 'shared'));
        if (!privateShare) await this.database.conflicts.put(conflict);
      }
      config.revision++;
      config.lastSyncAt = new Date().toISOString();
      if (payload.kind === 'share') config.shareSecretHash = hash;
      config.syncStatus = await this.database.conflicts.count() ? 'conflict' : 'imported';
      await this.database.meta.put({ key: 'config', value: config });
      return { added, conflicts: conflictCount, paired };
    });
  }
  async resolveConflict(id: string, choice: 'local' | 'remote') {
    await this.database.transaction('rw', this.database.tables, async () => {
      const conflict = await this.database.conflicts.get(id); if (!conflict) return;
      const config = await this.config();
      const siblings = await this.database.conflicts.where('entityId').equals(conflict.entityId).toArray();
      let current: RecordValue | undefined;
      if (conflict.kind === 'event') current = await this.database.events.get(conflict.entityId);
      if (conflict.kind === 'anniversary') current = await this.database.anniversaries.get(conflict.entityId);
      if (conflict.kind === 'couple') current = config.couple;
      if (conflict.kind === 'user') current = config.users.find(u => u.id === conflict.entityId);
      const record = revise(conflict[choice], config.deviceId, joinClocks(current?.clock ?? {}, conflict.local.clock, conflict.remote.clock));
      if (conflict.kind === 'event') {
        const event = eventSchema.parse(record);
        const privateOwner = current && 'visibility' in current && current.visibility === 'private';
        if (privateOwner && event.visibility === 'shared') throw new Error('비공개 일정은 충돌 선택으로 다시 공유할 수 없습니다.');
        await this.database.events.put(event);
      }
      if (conflict.kind === 'anniversary') await this.database.anniversaries.put(record as Anniversary);
      if (conflict.kind === 'couple') config.couple = record as Couple;
      if (conflict.kind === 'user') config.users = config.users.map(u => u.id === record.id ? record as User : u) as [User, User];
      await this.database.conflicts.delete(id);
      // Preserve further simultaneous candidates; make the chosen result their current candidate.
      for (const sibling of siblings.filter(c => c.id !== id)) await this.database.conflicts.put({ ...sibling, local: record });
      await this.changed(config);
    });
  }
}
export const repository = new CalendarRepository();
