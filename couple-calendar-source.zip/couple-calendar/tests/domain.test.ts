import { describe, expect, it } from 'vitest';
import { addDays, daysTogether, milestones, occurrences, onDate } from '../src/domain/dates';
import { newVersion, payloadSchema, type CalendarEvent, type Couple } from '../src/domain/model';
import { encryptPayload, parseFile, secretHash } from '../src/sync/files';
import { CalendarDatabase } from '../src/storage/database';
import { CalendarRepository } from '../src/storage/repository';

const device = crypto.randomUUID(), owner = crypto.randomUUID();
const event = (extra: Partial<CalendarEvent> = {}): CalendarEvent => ({ ...newVersion(device), title:'데이트', description:'', startAt:'2026-10-13T09:00:00.000Z', endAt:'2026-10-13T10:00:00.000Z', allDay:false, timeZone:'Asia/Seoul', ownerId:owner, visibility:'shared', category:'together', color:'#c97987', recurrenceRule:null, ...extra });
describe('calendar dates', () => {
  it('counts start as day 1 and 100th day inclusively', () => {
    expect(daysTogether('2026-01-01','2026-01-01')).toBe(1);
    const couple: Couple = {...newVersion(device),name:'우리',anniversaryDate:'2026-01-01'};
    expect(milestones(couple,[],'2026-01-01','2026-12-31').find(m => m.title === '함께한 100일')?.date).toBe(addDays('2026-01-01',99));
  });
  it('skips non-existent monthly 31st dates', () => {
    const e = event({startAt:'2026-01-31',endAt:'2026-02-01',allDay:true,recurrenceRule:{frequency:'monthly',until:null}});
    expect(occurrences([e],'2026-01-01','2026-04-30').map(i => i.date)).toEqual(['2026-01-31','2026-03-31']);
  });
  it('keeps recurrence in original time zone', () => {
    const e = event({startAt:'2026-03-07T14:00:00Z',endAt:'2026-03-07T15:00:00Z',timeZone:'America/New_York',recurrenceRule:{frequency:'daily',until:'2026-03-09'}});
    expect(occurrences([e],'2026-03-07','2026-03-10').map(i => i.start.hour)).toEqual([9,9,9]);
  });
  it('recurrence end is inclusive', () => {
    const e = event({recurrenceRule:{frequency:'daily',until:'2026-10-15'}});
    expect(occurrences([e],'2026-10-13','2026-10-20')).toHaveLength(3);
  });
  it('all-day multi-day ends exclusively', () => {
    const list = occurrences([event({startAt:'2026-10-13',endAt:'2026-10-15',allDay:true})],'2026-10-13','2026-10-16');
    expect(onDate(list,'2026-10-14')).toHaveLength(1); expect(onDate(list,'2026-10-15')).toHaveLength(0);
  });
  it('relationship Feb29 anniversary falls on Feb28 in non-leap years', () => {
    const couple: Couple = {...newVersion(device),name:'우리',anniversaryDate:'2024-02-29'};
    expect(milestones(couple,[],'2025-02-01','2025-03-01').find(m => m.title === '1주년 기념일')?.date).toBe('2025-02-28');
  });
});

async function space() {
  const database = new CalendarDatabase('test-' + crypto.randomUUID()), repo = new CalendarRepository(database);
  await repo.setup('우리','나','너','2026-01-01');
  return { database, repo };
}
async function add(repo: CalendarRepository, extra: Partial<CalendarEvent> = {}) {
  const s = (await repo.snapshot())!;
  const {id,clock,version,createdAt,updatedAt,deletedAt,updatedBy,...input} = event({...extra,ownerId:s.config.currentUserId});
  await repo.saveEvent(input);
  return (await repo.snapshot())!.events.at(-1)!;
}
const hash = 'a'.repeat(64);
describe('local storage and manual sharing', () => {
  it('retains an event after DB closes and reopens', async () => {
    const {database,repo} = await space(); const saved = await add(repo); const name = database.name;
    database.close(); const reopen = new CalendarDatabase(name);
    expect((await new CalendarRepository(reopen).snapshot())?.events[0].id).toBe(saved.id); await reopen.delete();
  });
  it('pairs a second device without a remote account', async () => {
    const a = await space(), b = new CalendarDatabase('test-' + crypto.randomUUID()), rb = new CalendarRepository(b);
    await add(a.repo); await rb.importPayload(await a.repo.createPayload('share'),hash);
    const sa=(await a.repo.snapshot())!, sb=(await rb.snapshot())!;
    expect(sb.config.couple.id).toBe(sa.config.couple.id); expect(sb.config.currentUserId).toBe(sa.config.users[1].id); expect(sb.events).toHaveLength(1);
    expect(sb.config.deviceId).not.toBe(sa.config.deviceId); await a.database.delete(); await b.delete();
  });
  it('excludes private content and imports files idempotently', async () => {
    const a=await space(), b=new CalendarDatabase('test-'+crypto.randomUUID()), rb=new CalendarRepository(b);
    await add(a.repo,{title:'PRIVATE SECRET',description:'private details',category:'personal',visibility:'private'}); await add(a.repo);
    const share=await a.repo.createPayload('share'); expect(JSON.stringify(share)).not.toContain('PRIVATE SECRET');
    await rb.importPayload(share,hash); await rb.importPayload(share,hash); expect((await rb.snapshot())!.events).toHaveLength(1);
    await a.database.delete(); await b.delete();
  });
  it('propagates deletions and rejects resurrection from old files', async () => {
    const a=await space(), b=new CalendarDatabase('test-'+crypto.randomUUID()), rb=new CalendarRepository(b);
    const record=await add(a.repo), old=await a.repo.createPayload('share'); await rb.importPayload(old,hash);
    await a.repo.deleteEvent(record.id); await rb.importPayload(await a.repo.createPayload('share'),hash); await rb.importPayload(old,hash);
    expect((await rb.snapshot())!.events[0].deletedAt).toBeTruthy(); await a.database.delete(); await b.delete();
  });
  it('withdraws a shared event when made private, without leaking private text', async () => {
    const a=await space(), b=new CalendarDatabase('test-'+crypto.randomUUID()), rb=new CalendarRepository(b);
    const record=await add(a.repo); await rb.importPayload(await a.repo.createPayload('share'),hash);
    await a.repo.saveEvent({...record,title:'SECRET',category:'personal',visibility:'private'},record.id);
    const share=await a.repo.createPayload('share'); expect(JSON.stringify(share)).not.toContain('SECRET'); await rb.importPayload(share,hash);
    expect((await rb.snapshot())!.events[0].deletedAt).toBeTruthy(); expect((await a.repo.snapshot())!.events[0].title).toBe('SECRET');
    await a.database.delete(); await b.delete();
  });
  it('preserves simultaneous candidates then resolves causally', async () => {
    const a=await space(), b=new CalendarDatabase('test-'+crypto.randomUUID()), rb=new CalendarRepository(b);
    const record=await add(a.repo); await rb.importPayload(await a.repo.createPayload('share'),hash);
    await a.repo.saveEvent({...record,title:'A edit'},record.id); const rbEvent=(await rb.snapshot())!.events[0]; await rb.saveEvent({...rbEvent,title:'B edit'},record.id);
    await a.repo.importPayload(await rb.createPayload('share'),hash); const sa=(await a.repo.snapshot())!;
    expect(sa.conflicts).toHaveLength(1); expect(sa.conflicts[0].remote).toMatchObject({title:'B edit'});
    await expect(a.repo.createPayload('share')).rejects.toThrow('충돌'); await a.repo.resolveConflict(sa.conflicts[0].id,'remote');
    await rb.importPayload(await a.repo.createPayload('share'),hash); expect((await rb.snapshot())!.events[0].title).toBe('B edit');
    expect((await rb.snapshot())!.conflicts).toHaveLength(0);
    await a.database.delete(); await b.delete();
  });
  it('restores full backup including private events', async () => {
    const a=await space(), b=new CalendarDatabase('test-'+crypto.randomUUID()), rb=new CalendarRepository(b);
    await add(a.repo,{title:'private',category:'personal',visibility:'private'}); const backup=await a.repo.createPayload('backup');
    await rb.importPayload(backup,null); await rb.importPayload(backup,null); expect((await rb.snapshot())!.events).toHaveLength(1);
    expect((await rb.snapshot())!.config.currentUserId).toBe((await a.repo.snapshot())!.config.currentUserId);
    await a.database.delete(); await b.delete();
  });
  it('rejects malformed files and foreign couples without mutation', async () => {
    const a=await space(), other=await space(); await add(a.repo); const before=await a.repo.snapshot();
    await expect(a.repo.importPayload(await other.repo.createPayload('share'),hash)).rejects.toThrow('다른 커플');
    const backup=await a.repo.createPayload('backup'); expect(payloadSchema.safeParse({...backup,schemaVersion:999}).success).toBe(false);
    expect((await a.repo.snapshot())!.events).toEqual(before!.events); await a.database.delete(); await other.database.delete();
  });
  it('rejects a wrong linked sharing key', async () => {
    const a=await space(), b=new CalendarDatabase('test-'+crypto.randomUUID()), rb=new CalendarRepository(b);
    await rb.importPayload(await a.repo.createPayload('share'),hash);
    await expect(rb.importPayload(await a.repo.createPayload('share'),'b'.repeat(64))).rejects.toThrow('암호'); await a.database.delete(); await b.delete();
  });
});

describe('encrypted files', () => {
  it('requires exactly four ASCII digits and preserves leading zeroes', async () => {
    await expect(secretHash('0123')).resolves.toHaveLength(64);
    for (const pin of ['123', '12345', '12a4', '１２３４', '1234 ']) await expect(secretHash(pin)).rejects.toThrow('숫자 4자리');
  });
  it('changes an existing secret without losing local events', async () => {
    const { database, repo } = await space(); await add(repo);
    const legacy = await secretHash('legacy-long-password', true);
    await repo.markExported('share', legacy, 1);
    await expect(repo.changeSharePin(await secretHash('9999'), await secretHash('0123'))).rejects.toThrow('기존 공유 암호');
    await repo.changeSharePin(legacy, await secretHash('0123'));
    expect((await repo.snapshot())!.events).toHaveLength(1);
    expect((await repo.snapshot())!.config.shareSecretHash).toBe(await secretHash('0123'));
    await database.delete();
  });
  it('round-trips data and rejects wrong passwords / oversized files', async () => {
    const {database,repo}=await space(); const payload=await repo.createPayload('share'); const password='0123';
    const contents=await encryptPayload(payload,password), file={size:contents.length,text:async()=>contents};
    expect(contents).not.toContain('데이트'); expect((await parseFile(file,password)).payload).toEqual(payload);
    await expect(parseFile(file,'9999')).rejects.toThrow('암호');
    await expect(parseFile({size:9*1024*1024,text:async()=>contents},password)).rejects.toThrow('8MB');
    expect(await secretHash(password)).toHaveLength(64); await database.delete();
  });
  it('rejects plaintext share files', async () => {
    const {database,repo}=await space(); const text=JSON.stringify(await repo.createPayload('share'));
    await expect(parseFile({size:text.length,text:async()=>text})).rejects.toThrow('암호화'); await database.delete();
  });
});
