"""Create a portable source archive without dependencies, Git data or runtime records."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[1]
target = root.parent / 'couple-calendar-source.zip'
excluded = {'.git', 'node_modules', '.pnpm-store', 'dist', 'test-results', 'playwright-report', '__pycache__'}
files = sorted(p for p in root.rglob('*') if p.is_file()
               and not any(part in excluded for part in p.relative_to(root).parts)
               and not p.name.startswith('.env') and not p.name.endswith('.tsbuildinfo'))
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for file in files:
        archive.write(file, 'couple-calendar/' + file.relative_to(root).as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None, 'Archive CRC verification failed'
    assert 'couple-calendar/README.md' in archive.namelist()
    assert 'couple-calendar/start-at-home.cmd' in archive.namelist()
    assert 'couple-calendar/.github/workflows/pages.yml' in archive.namelist()
digest = hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.sha256').write_text(digest + '  ' + target.name + '\n', encoding='utf-8')
print(json.dumps({'archive': str(target), 'files': len(files), 'bytes': target.stat().st_size, 'sha256': digest}, ensure_ascii=True))
