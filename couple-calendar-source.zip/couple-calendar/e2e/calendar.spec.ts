import { expect, test } from '@playwright/test';

test('real local CRUD persists through reload and offline reopening', async ({ page, context }) => {
  await page.goto('./'); await page.getByLabel('내 별명').fill('지우'); await page.getByLabel('상대방 별명').fill('서준'); await page.getByLabel('연애 시작일 · 선택').fill('2026-01-01'); await page.getByRole('button',{name:/캘린더 만들기/}).click();
  await page.getByRole('button',{name:/^일정 추가/}).click(); await page.getByLabel('일정 이름').fill('우리의 첫 약속'); await page.getByRole('switch',{name:'종일 일정'}).check(); await page.getByRole('button',{name:'일정 저장',exact:true}).click();
  await expect(page.getByText('우리의 첫 약속')).toBeVisible(); await page.reload(); await expect(page.getByText('우리의 첫 약속')).toBeVisible();
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload(); await context.setOffline(true); await page.reload(); await expect(page.getByText('우리의 첫 약속')).toBeVisible();
  await page.getByRole('button',{name:/^일정 추가/}).click(); await page.getByLabel('일정 이름').fill('오프라인 약속'); await page.getByRole('switch',{name:'종일 일정'}).check(); await page.getByRole('button',{name:'일정 저장',exact:true}).click(); await expect(page.getByText('오프라인 약속')).toBeVisible();
  await context.setOffline(false); await page.reload(); await expect(page.getByText('오프라인 약속')).toBeVisible();
  await page.getByRole('button',{name:/우리의 첫 약속/}).click(); await page.getByLabel('일정 이름').fill('수정된 약속'); await page.getByRole('button',{name:'변경 사항 저장'}).click(); await expect(page.getByText('수정된 약속')).toBeVisible();
  page.once('dialog',dialog=>dialog.accept()); await page.getByRole('button',{name:/수정된 약속/}).click(); await page.getByRole('button',{name:'삭제',exact:true}).click(); await expect(page.getByText('수정된 약속')).toHaveCount(0);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});
