import { useEffect, useRef, type ReactNode } from 'react';
import { Heart, LockKeyhole, Repeat2, X } from 'lucide-react';
import type { Occurrence } from '../domain/dates';
import type { AppConfig } from '../domain/model';

export function Modal({ title, children, onClose }: { title: string; children: ReactNode; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
    const el = ref.current!;
    const focusable = () => Array.from(el.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]')).filter(e => e.offsetParent !== null);
    (focusable().find(e => e.tagName === 'INPUT') ?? focusable()[0])?.focus();
    const listener = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
      if (event.key === 'Tab') {
        const elements = focusable(), first = elements[0], last = elements.at(-1);
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    el.addEventListener('keydown', listener);
    return () => { document.body.style.overflow = oldOverflow; previous?.focus(); el.removeEventListener('keydown', listener); };
  }, [onClose]);
  return <div className="modal-overlay"><div className="modal" role="dialog" aria-modal="true" aria-label={title} ref={ref}><div className="modal-heading"><h2>{title}</h2><button className="icon-button" onClick={onClose} aria-label="닫기"><X size={22} /></button></div>{children}</div></div>;
}
export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return <div className="empty"><span className="empty-heart"><Heart size={22} strokeWidth={1.5} /></span><strong>{title}</strong>{children && <p>{children}</p>}</div>;
}
export function EventList({ items, config, onEdit }: { items: Occurrence[]; config: AppConfig; onEdit: (item: Occurrence) => void }) {
  return <div className="event-list">{items.map(item => {
    const owner = config.users.find(u => u.id === item.event.ownerId)!;
    return <button key={item.key} className="event-row" onClick={() => onEdit(item)}>
      <span className="event-time">{item.event.allDay ? '종일' : item.start.setZone('Asia/Seoul').toFormat('HH:mm')}<small>{item.event.allDay ? '' : item.end.setZone('Asia/Seoul').toFormat('HH:mm')}</small></span>
      <span className="event-line" style={{ background: item.event.color }} />
      <span className="event-detail"><strong>{item.event.title}</strong><span>{item.event.category === 'together' ? '함께' : owner.nickname}{item.event.recurrenceRule && <Repeat2 size={12} />}{item.event.visibility === 'private' && <LockKeyhole size={12} />}</span></span>
      <span className="event-arrow">›</span>
    </button>;
  })}</div>;
}
export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return <div className="section-title"><h2>{title}</h2>{action && <button className="text-button" onClick={onAction}>{action} <span>↗</span></button>}</div>;
}
