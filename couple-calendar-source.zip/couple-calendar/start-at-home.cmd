@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 22.12 or newer on your personal laptop first.
  echo https://nodejs.org/en/download
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto failed
call npm test
if errorlevel 1 goto failed
call npm run test:portable
if errorlevel 1 goto failed
call npm run build
if errorlevel 1 goto failed
echo Open the Local URL shown below. Stop with Ctrl+C.
call npm run preview
exit /b
:failed
echo Setup or validation failed. Do not deploy until the error is fixed.
pause
exit /b 1
