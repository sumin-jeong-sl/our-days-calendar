import { z } from 'zod';
import { payloadSchema, type SharePayload } from '../domain/model';

export const firebaseConfigSchema = z.object({ apiKey: z.string().min(20).max(200), projectId: z.string().min(3).max(100), databaseURL: z.string().url().refine(v => /^https:\/\/[^/]+\.(firebaseio\.com|firebasedatabase\.app)\/?$/.test(v), 'Firebase 데이터베이스 HTTPS 주소가 필요합니다.'), appId: z.string().min(5).max(200), authDomain: z.string().max(200).optional() });
export const connectionSchema = z.object({ firebase: firebaseConfigSchema, room: z.string().regex(/^[a-f0-9]{64}$/), key: z.string().regex(/^[a-f0-9]{64}$/), coupleId: z.string().uuid() });
export type CloudConnection = z.infer<typeof connectionSchema>;
export type CloudFirebaseConfig = z.infer<typeof firebaseConfigSchema>;
const envelope = z.object({ v: z.literal(1), iv: z.string().max(40), data: z.string().max(1000000) });
const b64 = (bytes: Uint8Array) => { let text = ''; for (let i = 0; i < bytes.length; i += 8192) text += String.fromCharCode(...bytes.slice(i, i + 8192)); return btoa(text); };
const bytes = (text: string) => Uint8Array.from(atob(text), c => c.charCodeAt(0));
export const randomSecret = () => [...crypto.getRandomValues(new Uint8Array(32))].map(n => n.toString(16).padStart(2, '0')).join('');
async function aesKey(hex: string) {
  if (!/^[a-f0-9]{64}$/.test(hex)) throw new Error('연결 키가 올바르지 않습니다.');
  return crypto.subtle.importKey('raw', Uint8Array.from(hex.match(/../g)!, v => parseInt(v, 16)), 'AES-GCM', false, ['encrypt', 'decrypt']);
}
export async function sealCloud(payload: SharePayload, key: string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await aesKey(key), new TextEncoder().encode(JSON.stringify(payload)));
  const result = JSON.stringify({ v: 1, iv: b64(iv), data: b64(new Uint8Array(ciphertext)) });
  if (result.length > 950000) throw new Error('공유 데이터가 자동 동기화 크기 한도를 초과했습니다. 전체 백업을 저장하세요.');
  return result;
}
export async function openCloud(text: string, key: string): Promise<SharePayload> {
  if (text.length > 1000000) throw new Error('동기화 데이터가 너무 큽니다.');
  const e = envelope.parse(JSON.parse(text)), iv = bytes(e.iv);
  if (iv.length !== 12) throw new Error('동기화 데이터가 손상되었습니다.');
  const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, await aesKey(key), bytes(e.data));
  const parsed = payloadSchema.parse(JSON.parse(new TextDecoder().decode(plain)));
  if (parsed.kind !== 'share') throw new Error('자동 동기화에서 전체 백업을 받을 수 없습니다.');
  return parsed;
}
export function connectionLink(c: CloudConnection, base = location.href) {
  const url = new URL(base); url.hash = 'connect=' + btoa(JSON.stringify(connectionSchema.parse(c))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); return url.href;
}
export function parseConnectionLink(link: string): CloudConnection {
  const raw = new URL(link).hash.slice(1); if (!raw.startsWith('connect=') || raw.length > 4000) throw new Error('연결 링크가 올바르지 않습니다.');
  return connectionSchema.parse(JSON.parse(atob(raw.slice(8).replace(/-/g, '+').replace(/_/g, '/'))));
}
export function payloadFingerprint(payload: SharePayload) {
  const { exportedAt: _time, ...data } = payload; return JSON.stringify(data);
}
