import { defineConfig, devices } from '@playwright/test';
import { existsSync } from 'node:fs';
const existingEdge = ['C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', 'C:/Program Files/Microsoft/Edge/Application/msedge.exe'].find(existsSync);
const deployedURL = process.env.OUR_DAYS_BASE_URL;
export default defineConfig({
  testDir: './e2e', fullyParallel: false,
  use: { baseURL: deployedURL || 'http://127.0.0.1:4173/', ...devices['iPhone 13'], browserName: 'chromium', trace: 'retain-on-failure', launchOptions: { executablePath: process.env.OUR_DAYS_BROWSER_PATH || existingEdge } },
  webServer: deployedURL ? undefined : { command: `"${process.execPath}" node_modules/vite/bin/vite.js preview --host 127.0.0.1 --port 4173 --strictPort`, port: 4173, reuseExistingServer: !process.env.CI }
});
