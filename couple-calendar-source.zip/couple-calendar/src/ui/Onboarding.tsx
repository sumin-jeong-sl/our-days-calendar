import { useState } from 'react';
import { ArrowDownToLine, Heart, ShieldCheck } from 'lucide-react';
import { repository } from '../storage/repository';
import { parseFile } from '../sync/files';
import { SharePin } from './SharePin';
import { CloudPanel } from './CloudPanel';
import type { Payload } from '../domain/model';

export function Onboarding({ onImport }: { onImport: (payload: Payload, hash: string | null) => void }) {
  const [name, setName] = useState('우리의 날들'), [me, setMe] = useState(''), [partner, setPartner] = useState(''), [date, setDate] = useState('');
  const [password, setPassword] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  return <main className="onboarding"><div className="brand"><span className="brand-mark"><Heart size={22} /></span><span>우리의 날들</span></div><div className="onboarding-art"><span className="art-orbit" /><Heart size={64} strokeWidth={1.2} /><i>♥</i></div><p className="eyebrow">COUPLE CALENDAR</p><h1>커플 캘린더</h1><p className="intro">일정과 기념일을 관리하고 공유합니다.</p>
    <form className="form card onboarding-form" onSubmit={async e => { e.preventDefault(); setBusy(true); setError(''); try { await repository.setup(name, me, partner, date || null); } catch (err) { setError((err as Error).message); } finally { setBusy(false); } }}>
      <label>캘린더 이름<input value={name} onChange={e => setName(e.target.value)} required maxLength={60} /></label><div className="field-row"><label>내 별명<input placeholder="예: 지우" value={me} onChange={e => setMe(e.target.value)} maxLength={30} required /></label><label>상대방 별명<input placeholder="예: 서준" value={partner} onChange={e => setPartner(e.target.value)} maxLength={30} required /></label></div><label>연애 시작일 · 선택<input type="date" value={date} onChange={e => setDate(e.target.value)} /></label><button className="primary-button full" disabled={busy}>캘린더 만들기 <span>↗</span></button>
    </form><CloudPanel joinOnly /><div className="join-section"><h2>상대방이 먼저 만들었나요?</h2><p>공유 파일을 받았다면 새 공간을 만들지 않고 연결하세요. 전체 백업도 여기서 복원할 수 있습니다.</p><SharePin value={password} onChange={setPassword} label="공유 파일 PIN · 전체 백업은 입력 불필요" allowLegacy /><label className={`outline-button file-button ${busy ? 'disabled' : ''}`}><ArrowDownToLine size={17} /> 파일로 연결·복원<input type="file" accept=".json,application/json" disabled={busy} onChange={async e => { const file = e.target.files?.[0]; e.target.value = ''; if (!file) return; setBusy(true); setError(''); try { const parsed = await parseFile(file, password); onImport(parsed.payload, parsed.hash); setPassword(''); } catch (err) { setError((err as Error).message); } finally { setBusy(false); } }} /></label></div>{error && <p className="error" role="alert">{error}</p>}<p className="onboarding-privacy"><ShieldCheck size={15} /> 계정 가입 없이 · 내 기기에 먼저 저장</p>
  </main>;
}
