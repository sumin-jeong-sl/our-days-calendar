import { z } from 'zod';
import { DateTime } from 'luxon';

export const SCHEMA_VERSION = 1;
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v => DateTime.fromISO(v).isValid, '유효하지 않은 날짜');
const instant = z.string().datetime({ offset: true });
const id = z.string().uuid();
export const clockSchema = z.record(id, z.number().int().min(1).max(1e12));
const base = {
  id, clock: clockSchema, version: z.number().int().positive(),
  createdAt: instant, updatedAt: instant, deletedAt: instant.nullable(), updatedBy: id
};
export const userSchema = z.object({ ...base, nickname: z.string().min(1).max(30), color: z.string().regex(/^#[0-9a-fA-F]{6}$/) });
export const coupleSchema = z.object({ ...base, name: z.string().min(1).max(60), anniversaryDate: date.nullable() });
export const recurrenceSchema = z.object({ frequency: z.enum(['daily', 'weekly', 'monthly', 'yearly']), until: date.nullable() });
export const eventSchema = z.object({
  ...base, title: z.string().min(1).max(120), description: z.string().max(4000),
  startAt: z.string(), endAt: z.string(), allDay: z.boolean(),
  timeZone: z.string().max(60).refine(v => DateTime.now().setZone(v).isValid),
  ownerId: id, visibility: z.enum(['private', 'shared']), category: z.enum(['personal', 'together']),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/), recurrenceRule: recurrenceSchema.nullable()
}).superRefine((event, ctx) => {
  const start = DateTime.fromISO(event.startAt, { zone: event.timeZone });
  const end = DateTime.fromISO(event.endAt, { zone: event.timeZone });
  if (!start.isValid || !end.isValid || end <= start) ctx.addIssue({ code: 'custom', message: '종료는 시작보다 늦어야 합니다.' });
  if (event.allDay && (!date.safeParse(event.startAt).success || !date.safeParse(event.endAt).success)) ctx.addIssue({ code: 'custom', message: '종일 일정에는 날짜만 사용합니다.' });
  if (!event.allDay && (!instant.safeParse(event.startAt).success || !instant.safeParse(event.endAt).success)) ctx.addIssue({ code: 'custom', message: '시간 일정에는 시간대가 포함된 ISO 시간을 사용합니다.' });
  if (event.category === 'together' && event.visibility !== 'shared') ctx.addIssue({ code: 'custom', message: '함께하는 일정은 공유 일정입니다.' });
  if (event.recurrenceRule?.until && event.recurrenceRule.until < start.toISODate()!) ctx.addIssue({ code: 'custom', message: '반복 종료일이 시작일보다 빠릅니다.' });
});
export const anniversarySchema = z.object({ ...base, title: z.string().min(1).max(120), date, repeatType: z.enum(['once', 'yearly']) });
export const withdrawalSchema = z.object({ ...base, ownerId: id, deletedAt: instant });
export type Clock = z.infer<typeof clockSchema>;
export type User = z.infer<typeof userSchema>;
export type Couple = z.infer<typeof coupleSchema>;
export type CalendarEvent = z.infer<typeof eventSchema>;
export type Anniversary = z.infer<typeof anniversarySchema>;
export type Withdrawal = z.infer<typeof withdrawalSchema>;
export type Versioned = Pick<CalendarEvent, keyof typeof base>;
export type RecordValue = CalendarEvent | Anniversary | Couple | User;
export type EntityKind = 'event' | 'anniversary' | 'couple' | 'user';
const recordSchema = z.union([eventSchema, anniversarySchema, coupleSchema, userSchema]);
export const conflictSchema = z.object({ id: z.string().max(3000), kind: z.enum(['event', 'anniversary', 'couple', 'user']), entityId: id, local: recordSchema, remote: recordSchema });
export type Conflict = z.infer<typeof conflictSchema>;
export type SyncStatus = 'local' | 'exported' | 'imported' | 'conflict';
export interface AppConfig {
  couple: Couple; users: [User, User]; currentUserId: string;
  deviceId: string; revision: number; lastExportRevision: number;
  lastSyncAt: string | null; lastBackupAt: string | null; syncStatus: SyncStatus;
  shareSecretHash: string | null;
}
export interface Snapshot { config: AppConfig; events: CalendarEvent[]; anniversaries: Anniversary[]; withdrawals: Withdrawal[]; conflicts: Conflict[]; }
const common = {
  app: z.literal('our-days'), schemaVersion: z.literal(SCHEMA_VERSION), exportedAt: instant,
  couple: coupleSchema, users: z.tuple([userSchema, userSchema]),
  events: z.array(eventSchema).max(10000), anniversaries: z.array(anniversarySchema).max(1000),
  withdrawals: z.array(withdrawalSchema).max(10000)
};
export const payloadSchema = z.discriminatedUnion('kind', [
  z.object({ ...common, kind: z.literal('backup'), currentUserId: id, shareSecretHash: z.string().regex(/^[a-f0-9]{64}$/).nullable(), conflicts: z.array(conflictSchema).max(1000) }),
  z.object({ ...common, kind: z.literal('share'), senderId: id })
]).superRefine((p, ctx) => {
  const ids = p.users.map(u => u.id);
  if (ids[0] === ids[1] || !ids.includes(p.kind === 'backup' ? p.currentUserId : p.senderId)) ctx.addIssue({ code: 'custom', message: '사용자 정보가 올바르지 않습니다.' });
  if (p.events.some(e => !ids.includes(e.ownerId)) || p.withdrawals.some(e => !ids.includes(e.ownerId))) ctx.addIssue({ code: 'custom', message: '알 수 없는 일정 작성자입니다.' });
  if (p.kind === 'share' && p.events.some(e => e.visibility !== 'shared')) ctx.addIssue({ code: 'custom', message: '공유 파일에 비공개 일정이 들어 있습니다.' });
  for (const records of [p.events, p.anniversaries, p.withdrawals]) {
    if (new Set(records.map(e => e.id)).size !== records.length) ctx.addIssue({ code: 'custom', message: '파일 내부에 중복 ID가 있습니다.' });
  }
  if (p.kind === 'backup') {
    const schemas = { event: eventSchema, anniversary: anniversarySchema, couple: coupleSchema, user: userSchema };
    for (const c of p.conflicts) {
      if (!schemas[c.kind].safeParse(c.local).success || !schemas[c.kind].safeParse(c.remote).success || c.local.id !== c.entityId || c.remote.id !== c.entityId) ctx.addIssue({ code: 'custom', message: '충돌 사본이 올바르지 않습니다.' });
    }
  }
});
export type Payload = z.infer<typeof payloadSchema>;
export type SharePayload = Extract<Payload, { kind: 'share' }>;
export const PALETTE = ['#c97987', '#729c94', '#b491c8', '#c3a06e', '#809ec2', '#b58c7a'];

export function newVersion(deviceId: string): Versioned {
  const now = new Date().toISOString();
  return { id: crypto.randomUUID(), clock: { [deviceId]: 1 }, version: 1, createdAt: now, updatedAt: now, deletedAt: null, updatedBy: deviceId };
}
