import { useState, type FormEvent } from 'react';
import { DateTime } from 'luxon';
import { LockKeyhole, Trash2 } from 'lucide-react';
import { PALETTE, type AppConfig, type CalendarEvent } from '../domain/model';
import { addDays, ZONE } from '../domain/dates';
import { repository } from '../storage/repository';

export function EventEditor({ config, event, date, onSaved }: { config: AppConfig; event?: CalendarEvent; date: string; onSaved: () => void }) {
  const initial = event ? DateTime.fromISO(event.startAt, { zone: event.timeZone }).setZone(event.timeZone) : DateTime.fromISO(date + 'T18:00', { zone: ZONE });
  const initialEnd = event ? DateTime.fromISO(event.endAt, { zone: event.timeZone }).setZone(event.timeZone) : initial.plus({ hours: 1 });
  const [title, setTitle] = useState(event?.title ?? '');
  const [description, setDescription] = useState(event?.description ?? '');
  const [allDay, setAllDay] = useState(event?.allDay ?? false);
  const [startDate, setStartDate] = useState(initial.toISODate()!);
  const [endDate, setEndDate] = useState(event?.allDay ? addDays(initialEnd.toISODate()!, -1) : initialEnd.toISODate()!);
  const [startTime, setStartTime] = useState(initial.toFormat('HH:mm'));
  const [endTime, setEndTime] = useState(initialEnd.toFormat('HH:mm'));
  const [visibility, setVisibility] = useState<'private' | 'shared'>(event?.visibility ?? 'shared');
  const [category, setCategory] = useState<'personal' | 'together'>(event?.category ?? 'together');
  const [color, setColor] = useState(event?.color ?? PALETTE[0]);
  const [frequency, setFrequency] = useState<string>(event?.recurrenceRule?.frequency ?? 'none');
  const [until, setUntil] = useState(event?.recurrenceRule?.until ?? '');
  const [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const ownerId = event?.ownerId ?? config.currentUserId;
  const zone = event?.timeZone ?? ZONE;
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const startAt = allDay ? startDate : DateTime.fromISO(`${startDate}T${startTime}`, { zone }).toUTC().toISO()!;
      const endAt = allDay ? addDays(endDate, 1) : DateTime.fromISO(`${endDate}T${endTime}`, { zone }).toUTC().toISO()!;
      await repository.saveEvent({ title: title.trim(), description, allDay, startAt, endAt, timeZone: zone, ownerId, visibility, category, color, recurrenceRule: frequency === 'none' ? null : { frequency: frequency as 'daily' | 'weekly' | 'monthly' | 'yearly', until: until || null } }, event?.id, event?.clock);
      onSaved();
    } catch (err) { setError(err instanceof Error ? err.message : '저장하지 못했습니다.'); } finally { setBusy(false); }
  }
  async function remove() {
    if (!event || !window.confirm(event.recurrenceRule ? '반복 일정 전체를 삭제할까요?' : '이 일정을 삭제할까요?')) return;
    setBusy(true);
    try { await repository.deleteEvent(event.id, event.clock); onSaved(); } catch (err) { setError((err as Error).message); } finally { setBusy(false); }
  }
  return <form onSubmit={submit} className="form">
    <label>일정 이름<input placeholder="일정 제목" value={title} onChange={e => setTitle(e.target.value)} maxLength={120} required /></label>
    <div className="segmented"><button type="button" className={category === 'together' ? 'selected' : ''} onClick={() => { setCategory('together'); setVisibility('shared'); }}>함께하는 일정</button><button type="button" className={category === 'personal' ? 'selected' : ''} onClick={() => setCategory('personal')}>{config.users.find(u => u.id === ownerId)?.nickname}의 일정</button></div>
    <label className="switch-row"><span>종일 일정</span><input type="checkbox" role="switch" checked={allDay} onChange={e => setAllDay(e.target.checked)} /></label>
    <div className="field-row"><label>시작일<input type="date" value={startDate} onChange={e => { const next = e.target.value; setStartDate(next); if (next > endDate) setEndDate(next); }} required /></label>{!allDay && <label>시작 시간<input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} required /></label>}</div>
    <div className="field-row"><label>종료일<input type="date" value={endDate} min={startDate} onChange={e => setEndDate(e.target.value)} required /></label>{!allDay && <label>종료 시간<input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} required /></label>}</div>
    <label>반복<select value={frequency} onChange={e => setFrequency(e.target.value)}><option value="none">반복 안 함</option><option value="daily">매일</option><option value="weekly">매주</option><option value="monthly">매월 같은 날짜</option><option value="yearly">매년 같은 날짜</option></select></label>
    {frequency !== 'none' && <><label>반복 종료일 · 비우면 계속<input type="date" value={until} min={startDate} onChange={e => setUntil(e.target.value)} /></label><p className="hint">편집·삭제는 반복 전체에 적용됩니다. 존재하지 않는 날짜의 반복은 건너뜁니다.</p></>}
    <fieldset className="color-picker"><legend>일정 색상</legend>{PALETTE.map(c => <button key={c} type="button" aria-label={`색상 ${c}`} aria-pressed={c === color} style={{ background: c }} className={c === color ? 'chosen' : ''} onClick={() => setColor(c)} />)}</fieldset>
    <label>메모<textarea placeholder="장소 또는 상세 내용" value={description} onChange={e => setDescription(e.target.value)} maxLength={4000} rows={3} /></label>
    {category === 'personal' && ownerId === config.currentUserId && <label className="switch-row"><span><LockKeyhole size={15} /> 나만 보는 비공개 일정</span><input type="checkbox" role="switch" checked={visibility === 'private'} onChange={e => setVisibility(e.target.checked ? 'private' : 'shared')} /></label>}
    <p className="hint">{visibility === 'private' ? '비공개 내용은 공유 파일에 포함되지 않습니다.' : '이 기기에 저장되며 공유 설정에 따라 상대방에게 전달됩니다.'} 시간대: {zone}</p>
    {error && <p className="error" role="alert">{error}</p>}
    <div className="form-actions">{event && <button type="button" className="danger-button" disabled={busy} onClick={remove}><Trash2 size={17} /> 삭제</button>}<button className="primary-button" disabled={busy}>{busy ? '저장 중…' : event ? '변경 사항 저장' : '일정 저장'}</button></div>
  </form>;
}
