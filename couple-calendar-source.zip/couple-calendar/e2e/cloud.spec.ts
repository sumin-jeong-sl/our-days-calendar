import { expect, test } from '@playwright/test';

test('two real devices automatically exchange changes, retry offline, and preserve conflicts', async ({ page: a, browser }) => {
  test.skip(!process.env.OUR_DAYS_CLOUD_TEST, 'Run explicitly after configuring the free Firebase project.');
  test.setTimeout(120000);
  const bContext = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const b = await bContext.newPage(), cContext = await browser.newContext(), c = await cContext.newPage();
  const url = process.env.OUR_DAYS_BASE_URL || 'http://127.0.0.1:4173/';
  await a.goto(url); await a.getByLabel('내 별명').fill('검증 A'); await a.getByLabel('상대방 별명').fill('검증 B'); await a.getByLabel('연애 시작일 · 선택').fill('2025-01-01'); await a.getByRole('button', { name: /캘린더 만들기/ }).click();
  await a.getByRole('button', { name: '설정', exact: true }).click(); await a.getByRole('button', { name: '자동 공유 시작', exact: true }).click();
  await expect(a.getByLabel('두 사람 연결 링크')).toBeVisible({ timeout: 20000 }); const invite = await a.getByLabel('두 사람 연결 링크').inputValue();
  await b.goto(url); await b.getByLabel('상대방 연결 링크').fill(invite); await b.getByRole('button', { name: '연결 링크로 참여', exact: true }).click();
  await expect(b.getByRole('button', { name: '홈', exact: true })).toBeVisible({ timeout: 20000 });
  await c.goto(url); await c.getByLabel('상대방 연결 링크').fill(invite); await c.getByRole('button', { name: '연결 링크로 참여', exact: true }).click(); await expect(c.getByRole('alert')).toContainText('두 기기');
  await a.getByRole('button', { name: '홈', exact: true }).click();
  const add = async (p: typeof a, title: string, privateEvent = false) => {
    await p.getByRole('button', { name: /^일정 추가/ }).click(); await p.getByLabel('일정 이름').fill(title); await p.getByRole('switch', { name: '종일 일정' }).check();
    if (privateEvent) { await p.getByRole('button', { name: '검증 A의 일정', exact: true }).click(); await p.getByRole('switch', { name: /비공개 일정/ }).check(); }
    await p.getByRole('button', { name: '일정 저장', exact: true }).click();
  };
  await add(a, '자동 공유 확인'); await expect(b.getByText('자동 공유 확인')).toBeVisible({ timeout: 15000 });
  await add(a, '비공개 검증', true); await add(a, '공유 확인 두 번째'); await expect(b.getByText('공유 확인 두 번째')).toBeVisible({ timeout: 15000 }); await expect(b.getByText('비공개 검증')).toHaveCount(0);
  await bContext.setOffline(true); await add(b, '오프라인 자동 재전송'); await b.reload(); await expect(b.getByText('오프라인 자동 재전송')).toBeVisible();
  await bContext.setOffline(false); await expect(a.getByText('오프라인 자동 재전송')).toBeVisible({ timeout: 20000 });
  a.once('dialog', d => d.accept()); await a.getByRole('button', { name: /자동 공유 확인/ }).click(); await a.getByRole('button', { name: '삭제', exact: true }).click(); await expect(b.getByText('자동 공유 확인')).toHaveCount(0, { timeout: 15000 });
  await a.context().setOffline(true); await bContext.setOffline(true);
  for (const [p, title] of [[a, '동시 변경 A'], [b, '동시 변경 B']] as const) { await p.getByRole('button', { name: /공유 확인 두 번째/ }).click(); await p.getByLabel('일정 이름').fill(title); await p.getByRole('button', { name: '변경 사항 저장', exact: true }).click(); }
  await a.context().setOffline(false); await bContext.setOffline(false);
  // A received change can create a conflict before the local outgoing write.
  // One or both devices may therefore need review; both candidates must survive.
  const aConflict = a.getByRole('button', { name: /동시 수정 1건/ }), bConflict = b.getByRole('button', { name: /동시 수정 1건/ });
  await expect.poll(async () => (await aConflict.isVisible()) || (await bConflict.isVisible()), { timeout: 20000 }).toBe(true);
  const resolver = await aConflict.isVisible() ? a : b;
  await resolver.getByRole('button', { name: /동시 수정 1건/ }).click();
  const dialog = resolver.getByRole('dialog', { name: '동시 수정 확인', exact: true });
  await expect(dialog).toContainText('동시 변경 A'); await expect(dialog).toContainText('동시 변경 B');
  await dialog.locator('.conflict-options > div').filter({ hasText: '동시 변경 A' }).getByRole('button', { name: '이 버전 유지', exact: true }).click();
  await resolver.getByRole('button', { name: '닫기', exact: true }).click();
  await expect(a.getByText('동시 변경 A')).toBeVisible({ timeout: 20000 }); await expect(b.getByText('동시 변경 A')).toBeVisible({ timeout: 20000 });
  await expect(aConflict).toHaveCount(0); await expect(bConflict).toHaveCount(0);
  expect(await a.locator('body').innerText()).not.toContain('✳');
  await a.getByRole('button', { name: '홈', exact: true }).click();
  await expect(a.getByRole('status')).toBeHidden({ timeout: 7000 });
  await a.screenshot({ path: '../자동공유_수정화면.png' });
  await bContext.close(); await cContext.close();
});
