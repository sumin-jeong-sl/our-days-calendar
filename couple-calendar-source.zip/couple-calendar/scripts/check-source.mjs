import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { stripTypeScriptTypes } from 'node:module';

let count = 0;
async function walk(dir) {
  for (const item of await readdir(dir,{withFileTypes:true})) {
    const file=join(dir,item.name);
    if(item.isDirectory()) await walk(file);
    else if(file.endsWith('.ts')) { stripTypeScriptTypes(await readFile(file,'utf8'), { mode: 'transform' }); count++; }
  }
}
await walk('src'); await walk('tests');
JSON.parse(await readFile('package.json','utf8'));
JSON.parse(await readFile('tsconfig.json','utf8'));
const html=await readFile('index.html','utf8');
for (const asset of [...html.matchAll(/href="%BASE_URL%([^"?]+)"/g)].map(m=>m[1])) await readFile(join('public',asset));
console.log(`TypeScript syntax parsed: ${count} plain .ts files. JSON configs and HTML assets verified.`);
console.log('This is not JSX parsing, type checking, dependency resolution, a build, or browser testing.');
