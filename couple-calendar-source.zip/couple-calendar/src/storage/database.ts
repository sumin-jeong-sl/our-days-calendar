import Dexie, { type Table } from 'dexie';
import type { Anniversary, AppConfig, CalendarEvent, Conflict, Withdrawal } from '../domain/model';

export class CalendarDatabase extends Dexie {
  events!: Table<CalendarEvent, string>;
  anniversaries!: Table<Anniversary, string>;
  withdrawals!: Table<Withdrawal, string>;
  conflicts!: Table<Conflict, string>;
  meta!: Table<{ key: string; value: AppConfig }, string>;
  constructor(name = 'our-days-v1') {
    super(name);
    this.version(1).stores({ events: 'id,ownerId,startAt,updatedAt', anniversaries: 'id,date', withdrawals: 'id', conflicts: 'id,entityId,kind', meta: 'key' });
  }
}
export const db = new CalendarDatabase();

export async function requestPersistence(): Promise<boolean> {
  if (!navigator.storage?.persist) return false;
  return (await navigator.storage.persisted()) || navigator.storage.persist();
}
